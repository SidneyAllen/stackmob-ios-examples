/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <SDWebImage/UIImageView+WebCache.h>
#import <QuartzCore/QuartzCore.h>
#import "MOBViewPhotoViewController.h"
#import "MOBCommentViewController.h"
#import "MOBCommentTableViewCell.h"
#import "MOBTableViewController.h"
#import "MOBAppDelegate.h"
#import "FPPopoverController.h"
#import "MOBProfileViewController.h"
#import "MOBPictureViewController.h"


@interface MOBViewPhotoViewController ()

@end

@implementation MOBViewPhotoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadProfile:) name:@"loadProfile" object:nil];
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    Snap *snap = (Snap *)[context objectWithID:self.objectID];
    
    UIBarButtonItem *comment = [[UIBarButtonItem alloc] initWithTitle:@"Comment" style:UIBarButtonItemStyleBordered target:self action:@selector(writeComment:)];
    self.navigationItem.rightBarButtonItem = comment;
    
    NSString *user = snap.sm_owner;
    NSArray *components = [user componentsSeparatedByString:@"/"];
    NSString *facebookUserId = [components objectAtIndex:1];
    NSString *facebookPicURL = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture", facebookUserId];
    
    
    self.imageView.alpha = 0;
    self.imageView.layer.cornerRadius = 10.0f;
    self.imageView.clipsToBounds = YES;
    [UIView beginAnimations:@"fadeIn" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.3];
    
    TTTTimeIntervalFormatter *timeIntervalFormatter = [[TTTTimeIntervalFormatter alloc] init];
    NSTimeInterval utc = [snap.createddate unsignedLongLongValue]/1000;
    NSTimeInterval interval = [[NSDate dateWithTimeIntervalSince1970:utc] timeIntervalSinceDate:[NSDate date]];
    self.timeLabel.text = [timeIntervalFormatter stringForTimeInterval:interval];
    
    UITapGestureRecognizer *pictureTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadPictureView)];
    pictureTap.numberOfTapsRequired = 1;
    self.imageView.userInteractionEnabled = YES;
    [self.imageView addGestureRecognizer:pictureTap];
    
    UITapGestureRecognizer *profileTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadProfileView)];
    profileTap.numberOfTapsRequired = 1;
    self.profileImageView.userInteractionEnabled = YES;
    [self.profileImageView addGestureRecognizer:profileTap];
    
    [self.profileImageView setImageWithURL:[NSURL URLWithString:facebookPicURL] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    self.profileNameLabel.text = snap.creator;
    
    [self.imageView setImageWithURL:[NSURL URLWithString:snap.photo] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    
    self.imageView.alpha = 1;
    [UIView commitAnimations];
}


#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}


- (IBAction)writeComment:(id)sender {
    
    MOBCommentViewController *commentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"CommentViewController"];
    commentViewController.title = @"Comment";
    commentViewController.objectID = self.objectID;
    
    [self.navigationController pushViewController:commentViewController animated:YES];
}

- (void)loadProfile:(NSNotification *)notification {
    
    NSDictionary *userInfo = notification.userInfo;
    NSString *user = [userInfo objectForKey:@"user"];
    
    MOBProfileViewController *profileViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    profileViewController.title = @"Profile";
    
    profileViewController.isUserProfile = NO;
    profileViewController.user = user;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:profileViewController];
    
    [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)loadProfileView {
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    Snap *snap = (Snap *)[context objectWithID:self.objectID];
    NSString *user = snap.sm_owner;
    
    MOBProfileViewController *profileViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    profileViewController.title = @"Profile";
    
    profileViewController.isUserProfile = NO;
    profileViewController.user = user;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:profileViewController];
    
    [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)loadPictureView {
    
    MOBPictureViewController *pictureViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PictureViewController"];
    pictureViewController.image = [self.imageView image];
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    Snap *snap = (Snap *)[context objectWithID:self.objectID];
    pictureViewController.objectID = self.objectID;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *sm_owner = [defaults objectForKey:SNAPSTACK_SM_OWNER];
    
    if ([snap.sm_owner isEqualToString:sm_owner]) {
        pictureViewController.createdByUser = YES;
    }
    else {
        pictureViewController.createdByUser = NO;
    }
    
    [self.navigationController pushViewController:pictureViewController animated:YES];
}

- (IBAction)showComments:(id)sender {
    
    MOBTableViewController *tableViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"TableViewController"];
    tableViewController.objectID  = self.objectID;
    
    FPPopoverController *popover = [[FPPopoverController alloc] initWithViewController:tableViewController];
    popover.contentSize = CGSizeMake(320, 300);
    popover.delegate = tableViewController;
    
    [popover presentPopoverFromView:self.commentButton];
}
- (void)viewDidUnload {
    [self setCommentButton:nil];
    [self setTimeLabel:nil];
    [super viewDidUnload];
}

@end
