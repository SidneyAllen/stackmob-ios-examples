/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "MOBPictureViewController.h"
#import "MOBAppDelegate.h"

@interface MOBPictureViewController ()

@end

@implementation MOBPictureViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (self.createdByUser) {
        // Construct delete bar button item
        UIBarButtonItem *delete = [[UIBarButtonItem alloc] initWithTitle:@"Delete" style:UIBarButtonItemStyleBordered target:self action:@selector(presentActionSheet)];
        self.navigationItem.rightBarButtonItem = delete;
        
    }
    
    [self.imageView setImage:self.image];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setImageView:nil];
    [super viewDidUnload];
}

#pragma mark UIActionSheet delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    //Get the name of the current pressed button
    NSString *buttonTitle = [actionSheet buttonTitleAtIndex:buttonIndex];
    if  ([buttonTitle isEqualToString:@"Delete"]) {
        NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
        
        [context deleteObject:[context objectWithID:self.objectID]];
        
        [context saveOnSuccess:^{
            DLog(@"Successfully deleted object");
            NSNotification *notification = [NSNotification notificationWithName:LOAD_OBJECTS object:nil];
            [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationCoalescingOnName forModes:nil];
            
            NSInteger noOfViewControllers = [self.navigationController.viewControllers count];
            [self.navigationController popToViewController:[self.navigationController.viewControllers
                                                            objectAtIndex:(noOfViewControllers-3)] animated:YES];
        } onFailure:^(NSError *error) {
            DLog(@"Error deleting object: %@", error);
        }];
        
    }
}

#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)presentActionSheet {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:@"Are you sure you want to delete this photo?"
                                  delegate:self
                                  cancelButtonTitle:@"Cancel"
                                  destructiveButtonTitle:@"Delete"
                                  otherButtonTitles:nil];
    [actionSheet setActionSheetStyle:UIActionSheetStyleBlackOpaque];
    [actionSheet showInView:self.view];
}

@end
