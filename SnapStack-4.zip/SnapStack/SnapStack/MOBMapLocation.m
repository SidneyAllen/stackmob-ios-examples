/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "MOBMapLocation.h"

@interface MOBMapLocation ()

@property (nonatomic, strong) NSString *text;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong, readwrite) NSURL *photo;
@property (nonatomic, assign) CLLocationCoordinate2D location;

@end

@implementation MOBMapLocation

@synthesize photo = _photo;

- (id)initWithTitle:(NSString *)title subtitle:(NSString *)subtitle photo:(NSURL *)photo coordinate:(CLLocationCoordinate2D)coordinate {
    if ((self = [super init])) {
        self.text = title;
        self.name = subtitle;
        self.location = coordinate;
        self.photo = photo;
    }
    return self;
}


- (NSString *)title {
    return self.text;
}

- (NSString *)subtitle {
    return self.name;
}


- (CLLocationCoordinate2D)coordinate {
    return self.location;
}

@end
