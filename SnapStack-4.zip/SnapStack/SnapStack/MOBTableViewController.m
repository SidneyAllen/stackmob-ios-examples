/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <SDWebImage/UIImageView+WebCache.h>
#import "MOBTableViewController.h"
#import "MOBAppDelegate.h"
#import "MOBCommentTableViewCell.h"
#import "MOBViewPhotoViewController.h"
#import "MOBProfileViewController.h"

@interface MOBTableViewController ()

@end

@implementation MOBTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
    self.timeIntervalFormatter = [[TTTTimeIntervalFormatter alloc] init];
    
    [self loadComments];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    // Return the number of rows in the section.
    return [self.comments count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    MOBCommentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    
    
    
    if (cell == nil) {
        
        NSArray *bundle = [[NSBundle mainBundle] loadNibNamed:@"MOBCommentTableViewCell" owner:self options:nil];
        for (id nib in bundle) {
            if ([nib isKindOfClass:[MOBCommentTableViewCell class]]) {
                cell = (MOBCommentTableViewCell *)nib;
                break;
            }
        }
    }
    
    [cell setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    [cell.textView setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
    // Configure the cell...
    NSString *user;
    
    Comment *comment = [self.comments objectAtIndex:indexPath.row];
    cell.textView.text = comment.text;
    CGRect frame = cell.textView.frame;
    frame.size.height = cell.textView.contentSize.height;
    cell.textView.frame = frame;
    
    NSTimeInterval utc = [comment.createddate unsignedLongLongValue]/1000.0;
    NSTimeInterval interval = [[NSDate dateWithTimeIntervalSince1970:utc] timeIntervalSinceDate:[NSDate date]];
    cell.cellTimeLabel.text = [self.timeIntervalFormatter stringForTimeInterval:interval];
    
    
    cell.name.text = comment.creator;
    user = comment.sm_owner;
    
    
    UITapGestureRecognizer *profileTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadProfileView:)];
    profileTap.numberOfTapsRequired = 1;
    cell.profilePicture.userInteractionEnabled = YES;
    cell.profilePicture.tag = indexPath.row;
    [cell.profilePicture addGestureRecognizer:profileTap];
    
    NSArray *components = [user componentsSeparatedByString:@"/"];
    NSString *facebookUserId = [components objectAtIndex:1];
    NSString *facebookPicURL = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture", facebookUserId];
    [cell.profilePicture setImageWithURL:[NSURL URLWithString:facebookPicURL] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Comment *comment = [self.comments objectAtIndex:indexPath.row];
    
    static NSString *CellIdentifier = @"Cell";
    MOBCommentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        
        NSArray *bundle = [[NSBundle mainBundle] loadNibNamed:@"MOBCommentTableViewCell" owner:self options:nil];
        for (id nib in bundle) {
            if ([nib isKindOfClass:[MOBCommentTableViewCell class]]) {
                cell = (MOBCommentTableViewCell *)nib;
                break;
            }
        }
    }
    
    float oldHeight = cell.textView.frame.size.height;
    
    cell.textView.text = comment.text;
    
    
    CGRect frame = cell.textView.frame;
    frame.size.height = cell.textView.contentSize.height;
    cell.textView.frame = frame;
    
    float newHeight = cell.textView.frame.size.height;
    
    
    return COMMENT_CELL_HEIGHT - oldHeight + newHeight;
}

-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    Comment *comment = [self.comments objectAtIndex:indexPath.row];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *sm_owner = [defaults objectForKey:SNAPSTACK_SM_OWNER];
    
    if ([comment.sm_owner isEqualToString:sm_owner] ) {
        return UITableViewCellEditingStyleDelete;
    }
    
    return UITableViewCellEditingStyleNone;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        
        NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
        
        // Grab the comment
        Comment *comment = [self.comments objectAtIndex:indexPath.row];
        [context deleteObject:comment];
        
        // Save everything
        [context saveOnSuccess:^{
            NSLog(@"The save was successful!");
        } onFailure:^(NSError *error) {
            NSLog(@"The save wasn't successful: %@", [error userInfo]);
        }];
        
        // Delete object in UI
        NSMutableArray *array = [self.comments mutableCopy];
        [array removeObjectAtIndex:indexPath.row];
        self.comments = array;
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)loadComments {
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    
    // We'll be performing a retch request on the Snap entity
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Comment"
                                              inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    
    // Edit the sort key as appropriate.
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"createddate" ascending:NO];
    NSArray *sortDescriptors = [NSArray arrayWithObjects:sortDescriptor, nil];
    
    [fetchRequest setSortDescriptors:sortDescriptors];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"snap == %@",self.objectID];
    [fetchRequest setPredicate:predicate];
    
    [context executeFetchRequest:fetchRequest onSuccess:^(NSArray *results) {
        
        self.comments = results;
        [self.tableView reloadData];
        
    } onFailure:^(NSError *error) {
        
        DLog(@"Error performing query for objects: %@", error);
        
    }];
    
}

- (void) loadProfileView:(id) sender {
    
    UITapGestureRecognizer *gesture = (UITapGestureRecognizer *) sender;
    
    Comment *comment = [self.comments objectAtIndex:gesture.view.tag];
    NSString *user = comment.sm_owner;
    
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObject:user forKey:@"user"];
    NSNotification *notification = [NSNotification notificationWithName:@"loadProfile" object:nil userInfo:userInfo];
    [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationCoalescingOnSender forModes:nil];
}

@end
