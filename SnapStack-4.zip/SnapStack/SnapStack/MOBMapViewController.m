/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <QuartzCore/QuartzCore.h>
#import <MobileCoreServices/UTCoreTypes.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import "MOBMapLocation.h"
#import "RNBlurModalView.h"
#import "TTTTimeIntervalFormatter.h"
#import "MOBMapViewController.h"
#import "MOBViewPhotoViewController.h"
#import "RNBlurModalView.h"
#import "MOBAppDelegate.h"


#define METERS_PER_MILE 1609.344


@interface MOBMapViewController ()

@property (strong, nonatomic) RNBlurModalView *modal;
@property (strong, nonatomic) TTTTimeIntervalFormatter *timeIntervalFormatter;
@property (nonatomic, assign) BOOL activated;
@property (strong, nonatomic) UIActivityIndicatorView *activityIndicator;
@property (strong, nonatomic) NSArray *mapPhotos;

@end

@implementation MOBMapViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.refreshLabel.layer.cornerRadius = 10.0f;
    self.refreshLabel.clipsToBounds = YES;
    self.refreshLabel.alpha = 0.0;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    [self becomeFirstResponder];
    
    [NSTimer scheduledTimerWithTimeInterval:2.0
                                     target:self
                                   selector:@selector(showShakeLabel)
                                   userInfo:nil
                                    repeats:NO];
    [NSTimer scheduledTimerWithTimeInterval:5.0
                                     target:self
                                   selector:@selector(shake)
                                   userInfo:nil
                                    repeats:NO];
    [NSTimer scheduledTimerWithTimeInterval:8.0
                                     target:self
                                   selector:@selector(hideShakeLabel)
                                   userInfo:nil
                                    repeats:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refresh:) name:OBJECTS_LOADED object:nil];
    
    [self.modal hide];
    self.activityIndicator = [self showActivityIndicatorOnView:self.view];
    self.activated = TRUE;
    
    NSNotification *notification = [NSNotification notificationWithName:LOAD_OBJECTS object:nil];
    [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationCoalescingOnName forModes:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - MapView delegate

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
    if ([annotation isKindOfClass:[MOBMapLocation class]]) {
        return [self viewForMOBMapLocation:annotation];
    }
    
    return nil;
}

- (MKAnnotationView *)viewForMOBMapLocation:(MOBMapLocation *)annotation {
    
    static NSString *identifier = @"MOBMapLocation";
    
    MKPinAnnotationView *annotationView = (MKPinAnnotationView *) [self.mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (annotationView == nil) {
        annotationView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        annotationView.enabled = YES;
        annotationView.canShowCallout = NO;
        [annotationView setAnimatesDrop:YES];
    } else {
        annotationView.annotation = annotation;
    }
    
    return annotationView;
}


- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view {
    
    if ([view.annotation isKindOfClass:[MOBMapLocation class]]) {
        MOBMapLocation *annotation = view.annotation;
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 260, 260)];
        [imageView setImageWithURL:[annotation photo] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
        
        imageView.layer.cornerRadius = 10.0f;
        imageView.clipsToBounds = YES;
        
        UITapGestureRecognizer *tapped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadPhotoView:)];
        tapped.numberOfTapsRequired = 1;
        imageView.userInteractionEnabled = YES;
        [imageView addGestureRecognizer:tapped];
        
        self.modal = [[RNBlurModalView alloc] initWithViewController:self view:imageView];
        [self.modal show];
    }
}

#pragma mark - Shaking
- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
    if ( event.subtype == UIEventSubtypeMotionShake )
    {
        if (!self.activated) {
            
            [self.modal hide];
            self.activityIndicator = [self showActivityIndicatorOnView:self.view];
            self.activated = TRUE;
            
            NSNotification *notification = [NSNotification notificationWithName:LOAD_OBJECTS object:nil];
            [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationCoalescingOnName forModes:nil];
        }
    }
    
    if ( [super respondsToSelector:@selector(motionEnded:withEvent:)] )
        [super motionEnded:motion withEvent:event];
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)refresh:(NSNotification *)notification {
    
    NSDictionary *userInfo = notification.userInfo;
    self.mapPhotos = [userInfo objectForKey:@"objects"];
    [self addAnnotations];
    [self.activityIndicator removeFromSuperview];
    self.activated = FALSE;
}

- (void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated {
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"viewTouched" object:nil];
}

- (void)addAnnotations
{
    for (id<MKAnnotation> annotation in self.mapView.annotations) {
        [self.mapView removeAnnotation:annotation];
    }
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    
    for (NSManagedObjectID *objectID in self.mapPhotos) {
        
        Snap *snap = (Snap *)[context objectWithID:objectID];
        
        NSURL *url = [NSURL URLWithString:snap.photo];
        NSDictionary *location = [NSKeyedUnarchiver unarchiveObjectWithData:snap.location];
        
        CLLocationCoordinate2D coordinate;
        coordinate.latitude = [[location objectForKey:@"lat"] doubleValue];
        coordinate.longitude = [[location objectForKey:@"lon"] doubleValue];
        
        
        MOBMapLocation *annotation = [[MOBMapLocation alloc] initWithTitle:snap.creator subtitle:nil photo:url coordinate:coordinate];
        
        annotation.tag = (NSInteger *)[self.mapPhotos indexOfObject:objectID];
        
        [self.mapView addAnnotation:annotation];
    }
    
    MKMapPoint userAnnotationPoint = MKMapPointForCoordinate(self.mapView.userLocation.coordinate);
    
    MKMapRect zoomRect = MKMapRectMake(userAnnotationPoint.x, userAnnotationPoint.y, 0.1, 0.1);
    for (id <MKAnnotation> annotation in self.mapView.annotations)
    {
        MKMapPoint annotationPoint = MKMapPointForCoordinate(annotation.coordinate);
        MKMapRect pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0.1, 0.1);
        if (MKMapRectIsNull(zoomRect)) {
            zoomRect = pointRect;
        } else {
            zoomRect = MKMapRectUnion(zoomRect, pointRect);
        }
    }
    
    [self.mapView setVisibleMapRect:zoomRect edgePadding:UIEdgeInsetsMake(20.0, 20.0, 20.0, 20.0) animated:YES];
}

- (UIActivityIndicatorView *)showActivityIndicatorOnView:(UIView*)aView
{
    CGSize viewSize = aView.bounds.size;
    
    // create new dialog box view and components
    UIActivityIndicatorView *activityIndicatorView = [[UIActivityIndicatorView alloc]
                                                      initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    // other size? change it
    activityIndicatorView.bounds = CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height );
    activityIndicatorView.hidesWhenStopped = YES;
    activityIndicatorView.alpha = 0.6f;
    activityIndicatorView.backgroundColor = [UIColor blackColor];
    
    // display it in the center of your view
    activityIndicatorView.center = CGPointMake(viewSize.width / 2.0, viewSize.height / 2.0);
    
    [aView addSubview:activityIndicatorView];
    
    [activityIndicatorView startAnimating];
    
    return activityIndicatorView;
}

- (void)loadPhotoView :(id) sender {
    
    MOBViewPhotoViewController *viewPhotoViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewPhotoViewController"];
    viewPhotoViewController.title = @"View Photo";
    
    MOBMapLocation *annotation = [[self.mapView selectedAnnotations] objectAtIndex:0];
    
    viewPhotoViewController.objectID = [self.mapPhotos objectAtIndex:(NSUInteger)annotation.tag];
    
    [self.tabBarController.navigationController pushViewController:viewPhotoViewController animated:YES];
}

- (void)showShakeLabel {
    
    [UIView beginAnimations:@"fadeIn" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.3];
    
    self.refreshLabel.alpha = 1;
    
    [UIView commitAnimations];
}

- (void)hideShakeLabel {
    
    [UIView beginAnimations:@"fadeIn" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.3];
    
    self.refreshLabel.alpha = 0;
    
    [UIView commitAnimations];
}

- (void)shake {
    CABasicAnimation *animation1 =
    [CABasicAnimation animationWithKeyPath:@"position"];
    [animation1 setDuration:0.05];
    [animation1 setRepeatCount:5];
    [animation1 setAutoreverses:YES];
    [animation1 setFromValue:[NSValue valueWithCGPoint:
                              CGPointMake([self.refreshLabel center].x - 10.0f, [self.refreshLabel center].y)]];
    [animation1 setToValue:[NSValue valueWithCGPoint:
                            CGPointMake([self.refreshLabel center].x + 10.0f, [self.refreshLabel center].y)]];
    [[self.refreshLabel layer] addAnimation:animation1 forKey:@"position"];
}


- (void)viewDidUnload {
    [self setRefreshLabel:nil];
    [super viewDidUnload];
}
@end
