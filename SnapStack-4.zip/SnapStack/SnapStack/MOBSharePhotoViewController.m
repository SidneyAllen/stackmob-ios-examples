/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <FacebookSDK/FacebookSDK.h>
#import "MOBSharePhotoViewController.h"
#import "MOBAppDelegate.h"

@interface MOBSharePhotoViewController ()

@end

@implementation MOBSharePhotoViewController

@synthesize facebookSwitch;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.scrollView.contentSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.height + 100);
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    [self.imageView setImage:self.image];
    [self.view setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
    [[[self appDelegate] client] getLoggedInUserFacebookInfoWithOnSuccess:^(NSDictionary *result) {
        
        self.name = [result objectForKey:@"name"];
        self.firstName = [result objectForKey:@"first_name"];
        
        
    } onFailure:^(NSError *error) {
        DLog(@"Error getting user Facebook info:m %@", error);
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Textfield delegate

// called when textField start editting.
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self.scrollView setContentOffset:CGPointMake(0,textField.center.y/2) animated:YES];
    self.scrollView.contentSize = self.view.bounds.size;
}

// called when click on the retun button.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self sharePhoto:self];
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSUInteger newLength = [textField.text length] + [string length] - range.length;
    return (newLength > 240) ? NO : YES;
}

#pragma mark - Scrollview delegate


- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self.textField resignFirstResponder];
}


#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (IBAction)dismiss:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)getPermissions {
    // Ask for publish_actions permissions in context
    if ([FBSession.activeSession.permissions
         indexOfObject:@"publish_actions"] == NSNotFound) {
        // No permissions found in session, ask for it
        [FBSession.activeSession
         reauthorizeWithPublishPermissions:
         [NSArray arrayWithObject:@"publish_actions"]
         defaultAudience:FBSessionDefaultAudienceFriends
         completionHandler:^(FBSession *session, NSError *error) {
             if (!error) {
                 // If permissions granted, publish the story
                 [self publishToFacebook];
             }
         }];
    } else {
        // If permissions present, publish the story
        [self publishToFacebook];
    }
}

- (void)publishToFacebook {
    NSMutableDictionary  *postParams =[[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                       UIImagePNGRepresentation(self.image), @"picture", self.textField.text, @"name",
                                       @"SnapStack: a photos app built on the StackMob platform", @"caption",
                                       @"Take photos and share them with people nearby, instantly!", @"description",nil];
    
    [FBRequestConnection
     startWithGraphPath:@"me/photos"
     parameters:postParams
     HTTPMethod:@"POST"
     completionHandler:^(FBRequestConnection *connection,
                         id result,
                         NSError *error) {
         NSString *alertText = @"There was an error posting to Facebook.";
         // Show the result in an alert
         [[[UIAlertView alloc] initWithTitle:@"Oops..."
                                     message:alertText
                                    delegate:self
                           cancelButtonTitle:@"OK"
                           otherButtonTitles:nil] show];
     }];
}

- (IBAction)sharePhoto:(id)sender {
    
    self.shareButton.enabled = NO;
    
    [self.textField resignFirstResponder];
    
    [SMGeoPoint getGeoPointForCurrentLocationOnSuccess:^(SMGeoPoint *geoPoint) {
        
        NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
        
        Snap *snap = [NSEntityDescription insertNewObjectForEntityForName:@"Snap" inManagedObjectContext:context];
        
        snap.snapId = [snap assignObjectId];
        snap.creator = self.name;
        
        //Serialize the image into binary string data
        NSData *imageData = UIImageJPEGRepresentation(self.image, 0.5);
        snap.photo = [SMBinaryDataConversion
                      stringForBinaryData:imageData
                      name:@"pic.jpg" contentType:@"image/jpg"];
        
        // Save the location as data
        snap.location = [NSKeyedArchiver archivedDataWithRootObject:geoPoint];
        
        // Save snap object
        [context saveOnSuccess:^{
            DLog(@"Success creating object");
            
            if ([self.facebookSwitch isOn]) {
                [self getPermissions];
            }
            
            NSString *trimmedText = [self.textField.text stringByTrimmingCharactersInSet:
                                     [NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if (trimmedText.length != 0) {
                
                NSManagedObjectContext *newContext = [[[self appDelegate] coreDataStore] contextForCurrentThread];
                
                Comment *comment = [NSEntityDescription insertNewObjectForEntityForName:@"Comment" inManagedObjectContext:newContext];
                comment.commentId = [comment assignObjectId];
                comment.creator = self.name;
                comment.text = self.textField.text;
                [comment setSnap:snap];
                NSError *error = nil;
                if (![newContext saveAndWait:&error]) {
                    DLog(@"Error saving comment: %@", [error userInfo]);
                } else {
                    DLog(@"Succesfully saved comment");
                }
            }
            
            NSNotification *notification = [NSNotification notificationWithName:LOAD_OBJECTS object:nil];
            [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationCoalescingOnName forModes:nil];
            
            [self dismissViewControllerAnimated:YES completion:nil];
        } onFailure:^(NSError *error) {
            
            DLog(@"Error creating object: %@", error);
            
            // Show the result in an alert
            [[[UIAlertView alloc] initWithTitle:@"Oops!"
                                        message:@"There was an error posting your photo"
                                       delegate:self
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil]
             show];
            
            self.shareButton.enabled = YES;
            
        }];
    } onFailure:^(NSError *error) {
        
        // Alert the user that there was an error
        [[[UIAlertView alloc] initWithTitle:@"Oops!"
                                    message:@"There was an error getting your location"
                                   delegate:self
                          cancelButtonTitle:@"OK"
                          otherButtonTitles: nil]
         show];
        
        self.shareButton.enabled = YES;
    }];
}

@end
