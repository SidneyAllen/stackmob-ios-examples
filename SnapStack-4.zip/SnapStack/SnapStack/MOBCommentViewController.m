/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "MOBCommentViewController.h"
#import "MOBAppDelegate.h"

@interface MOBCommentViewController ()

@end

@implementation MOBCommentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.pushClient = [[self appDelegate] pushClient];
    
    [self.textField becomeFirstResponder];
    
    self.navigationController.title = @"Comment";
    
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Textfield delegate

// called when textField start editting.
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}

// called when click on the retun button.
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self sendText];
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSUInteger newLength = [textField.text length] + [string length] - range.length;
    return (newLength > 999)? NO : YES;
}

#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)sendText {
    
    [self.textField resignFirstResponder];
    
    NSString *trimmedText = [self.textField.text stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trimmedText.length == 0) {
        return;
    }
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    Snap *snap = (Snap *)[context objectWithID:self.objectID];
    
    [[[self appDelegate] client] getLoggedInUserFacebookInfoWithOnSuccess:^(NSDictionary *result) {
        
        [self.navigationController popViewControllerAnimated:YES];
        
        NSString *name = [result objectForKey:@"name"];
        NSString *firstname = [result objectForKey:@"first_name"];
        
        NSManagedObjectContext *newContext = [[[self appDelegate] coreDataStore] contextForCurrentThread];
        Comment *comment = [NSEntityDescription insertNewObjectForEntityForName:@"Comment" inManagedObjectContext:newContext];
        
        comment.commentId = [comment assignObjectId];
        comment.text = self.textField.text;
        comment.creator = name;
        [comment setSnap:snap];
        
        [context saveOnSuccess:^{
            
            DLog(@"Succesfully saved comment");
            [self.navigationController popViewControllerAnimated:YES];
            
            NSString *message = [NSString stringWithFormat:@"%@ commented on your photo!", firstname];
            
            NSMutableDictionary *pushMessage = [NSMutableDictionary dictionaryWithCapacity:1];
            
            [pushMessage setValue:message forKey:@"alert"];
            [pushMessage setValue:snap.snapId forKey:@"snapId"];
            
            NSString *user = snap.sm_owner;
            NSArray *components = [user componentsSeparatedByString:@"/"];
            NSString *facebookUserId = [components objectAtIndex:1];
            
            NSArray *users = [NSArray arrayWithObject:facebookUserId];
            
            [self.pushClient sendMessage:pushMessage toUsers:users onSuccess:^{
                DLog(@"Succesfully sent push message");
            } onFailure:^(NSError *error) {
                DLog(@"Error sending broadcast push message: %@", error);
            }];
            
            
            
        } onFailure:^(NSError *error) {
            DLog(@"Error saving comment: %@", error);
        }];
        
    } onFailure:^(NSError *error) {
        DLog(@"Error getting Facebook info: %@", error);
    }];
    
}





@end
