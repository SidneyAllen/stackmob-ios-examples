//
//  main.m
//  SnapStack
//
//  Created by Carl Atupem on 2/19/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MOBAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MOBAppDelegate class]));
    }
}
