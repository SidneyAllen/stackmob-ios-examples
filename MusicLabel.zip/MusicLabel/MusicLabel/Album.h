//
//  Album.h
//  MusicLabel
//
//  Created by Carl Atupem on 11/6/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Artist;

@interface Album : NSManagedObject

@property (nonatomic, retain) NSDate * released;
@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) Artist *artist;

@end
