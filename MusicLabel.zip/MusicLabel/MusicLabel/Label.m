//
//  Label.m
//  MusicLabel
//
//  Created by Carl Atupem on 11/6/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "Label.h"


@implementation Label

@dynamic founded;
@dynamic genre;
@dynamic name;
@dynamic artists;

@end
