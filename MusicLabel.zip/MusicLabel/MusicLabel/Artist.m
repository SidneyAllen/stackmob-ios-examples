//
//  Artist.m
//  MusicLabel
//
//  Created by Carl Atupem on 11/6/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "Artist.h"
#import "Label.h"


@implementation Artist

@dynamic hometown;
@dynamic name;
@dynamic label;
@dynamic albums;

@end
