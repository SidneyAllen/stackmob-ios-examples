//
//  MLBLLabelEntryViewController.m
//  MusicLabel
//
//  Created by Carl Atupem on 5/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//


#import "MLBLLabelEntryViewController.h"
#import "MLBLAppDelegate.h"
#import "Label.h"

@interface MLBLLabelEntryViewController ()

@end


@implementation MLBLLabelEntryViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // This will call our
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonItemStyleBordered target:self action:@selector(addLabel)];
    self.navigationItem.rightBarButtonItem = item;
    
    UIBarButtonItem *item2 = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(dismiss)];
    self.navigationItem.leftBarButtonItem = item2;
}

#pragma mark - private methods

- (MLBLAppDelegate *)appDelegate {
    return (MLBLAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void) addLabel {
    
    // Grab the context
    NSManagedObjectContext *context = [[self appDelegate] managedObjectContext];
    
    // Grab the Label entity
    Label *label = [NSEntityDescription insertNewObjectForEntityForName:@"Label" inManagedObjectContext:context];
    
    // Set label name
    label.name = self.labelField.text;
    
    
    // Save everything
    NSError *error = nil;
    if ([context save:&error]) {
        NSLog(@"The save was successful!");
    } else {
        NSLog(@"The save wasn't successful: %@", [error userInfo]);
    }
    
    [self dismiss];
}

- (void) dismiss {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end