//
//  Album.m
//  MusicLabel
//
//  Created by Carl Atupem on 11/6/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "Album.h"
#import "Artist.h"


@implementation Album

@dynamic released;
@dynamic title;
@dynamic artist;

@end
