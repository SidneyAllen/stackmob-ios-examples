//
//  MLBLLabelViewController.h
//  MusicLabel
//
//  Created by Carl Atupem on 5/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MLBLAppDelegate.h"
#import "Label.h"

@interface MLBLLabelViewController : UITableViewController

// An array to house all of our fetched Label objects
@property (strong, nonatomic) NSArray *labelArray;

@end
