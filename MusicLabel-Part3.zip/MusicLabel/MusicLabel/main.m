//
//  main.m
//  MusicLabel
//
//  Created by Carl Atupem on 11/2/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MLBLAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MLBLAppDelegate class]));
    }
}
