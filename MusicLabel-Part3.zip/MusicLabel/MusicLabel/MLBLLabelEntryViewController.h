//
//  MLBLLabelEntryViewController.h
//  MusicLabel
//
//  Created by Carl Atupem on 5/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MLBLLabelEntryViewController : UITableViewController
@property (strong, nonatomic) IBOutlet UITextField *labelField;

@end
