//
//  MLBLArtistViewController.m
//  MusicLabel
//
//  Created by Carl Atupem on 5/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import "MLBLArtistViewController.h"

@interface MLBLArtistViewController ()

@end

@implementation MLBLArtistViewController

@synthesize artistArray;

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self loadTableData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // We only need to return 1 for this table view
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // We'll return the count of the objects in artistArray
    return [artistArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    // Grab the artist
    Artist *artist = [self.artistArray objectAtIndex:indexPath.row];
    cell.textLabel.text = artist.name;
    
    return cell;
}

#pragma mark - Private methods

- (MLBLAppDelegate *)appDelegate {
    return (MLBLAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void) loadTableData {
    
    NSManagedObjectContext *context = [[self appDelegate] managedObjectContext];
    
    // Construct a fetch request
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Artist"
                                              inManagedObjectContext:context];
    
    [fetchRequest setEntity:entity];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"label == %@", [context objectWithID:self.labelID]];
    [fetchRequest setPredicate:predicate];
    
    // Add an NSSortDescriptor to sort the labels alphabetically
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    [fetchRequest setSortDescriptors:sortDescriptors];
    
    
    NSError *error = nil;
    self.artistArray = [context executeFetchRequest:fetchRequest error:&error];
    [self.tableView reloadData];
}

@end
