#import <UIKit/UIKit.h>
#import "MLBLAppDelegate.h"
#import "Label.h"
#import "Artist.h"

@interface MLBLArtistViewController : UITableViewController

// An array to house all of our fetched Artist objects
@property (strong, nonatomic) NSArray *artistArray;

//The id of the parent object
@property (strong, nonatomic) NSManagedObjectID *labelID;

@end