/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <UIKit/UIKit.h>
#import "StackMob.h"
#import "Snap.h"
#import "Comment.h"

#define BACKGROUND_COLOR @"e5e5e1"
#define FILTER_COLOR @"a0cd36"
#define LOAD_OBJECTS @"loadObjects"
#define OBJECTS_LOADED @"objectsLoaded"
#define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
#define SNAPSTACK_SM_OWNER @"snapstack_sm_owner"

@class SMClient;
@class SMCoreDataStore;
@class SMPushClient;

@interface MOBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) SMClient *client;
@property (strong, nonatomic) SMCoreDataStore *coreDataStore;
@property (strong, nonatomic) SMPushClient *pushClient;
@property (strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (strong, nonatomic) UIViewController *viewController;
@property (strong, nonatomic) UIWindow *window;

// This method will be useful for creating colors
- (UIColor*)colorWithHexString:(NSString*)hex;

@end
