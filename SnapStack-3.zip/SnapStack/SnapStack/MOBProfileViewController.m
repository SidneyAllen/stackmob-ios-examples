/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <SDWebImage/UIImageView+WebCache.h>
#import <QuartzCore/QuartzCore.h>
#import "MOBProfileViewController.h"
#import "MOBAppDelegate.h"
#import "MOBTableViewCell.h"
#import "MOBViewPhotoViewController.h"

@interface MOBProfileViewController ()

@end

@implementation MOBProfileViewController

@synthesize userPhotos;

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
        
    if (self.isUserProfile) {
        
        [[FBRequest requestForMe] startWithCompletionHandler:
         ^(FBRequestConnection *connection,
           NSDictionary<FBGraphUser> *user,
           NSError *error) {
             if (!error) {
                 self.profileLabel.text = user.name;
                 self.profilePictureView.profileID = user.id;
             }
         }];
    }
    else {
        
        NSArray *components = [self.user componentsSeparatedByString:@"/"];
        NSString *facebookUserId = [components objectAtIndex:1];
        
        [[FBRequest requestForGraphPath:facebookUserId] startWithCompletionHandler:
         ^(FBRequestConnection *connection,
           NSDictionary<FBGraphUser> *user,
           NSError *error) {
             if (!error) {
                 self.profileLabel.text = user.name;
                 self.profilePictureView.profileID = user.id;
             }
         }];
    }
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self loadPhotos];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadPhotos) name:OBJECTS_LOADED object:nil];
    
    [self.view setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    [self.tableView setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
    self.timeIntervalFormatter = [[TTTTimeIntervalFormatter alloc] init];
    
    [self.navigationController setTitle:@"Profile"];
    
    UIBarButtonItem *dismiss = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(dismiss:)];
    self.navigationItem.leftBarButtonItem = dismiss;
    
    if (self.isUserProfile) {
        
        UIBarButtonItem *logOut = [[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered target:self action:@selector(logOut:)];
        self.navigationItem.rightBarButtonItem = logOut;
    }
    else {
        UITapGestureRecognizer *profileTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadFacebookProfile)];
        profileTap.numberOfTapsRequired = 1;
        self.profilePictureView.userInteractionEnabled = YES;
        [self.profilePictureView addGestureRecognizer:profileTap];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    // Return the number of rows in the section.
    return [userPhotos count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Configure the cell...
    
    MOBTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (cell == nil) {
        
        NSArray *bundle = [[NSBundle mainBundle] loadNibNamed:@"MOBTableViewCell" owner:self options:nil];
        for (id nib in bundle) {
            if ([nib isKindOfClass:[MOBTableViewCell class]]) {
                cell = (MOBTableViewCell *)nib;
                break;
            }
        }
    }
    
    [cell.contentView setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
    Snap *snap = [userPhotos objectAtIndex:indexPath.row];
    
    NSTimeInterval utc = [snap.createddate unsignedLongLongValue]/1000;
    NSTimeInterval interval = [[NSDate dateWithTimeIntervalSince1970:utc] timeIntervalSinceDate:[NSDate date]];
    cell.cellTimeLabel.text = [self.timeIntervalFormatter stringForTimeInterval:interval];
    
    UITapGestureRecognizer *tapped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadPhotoView:)];
    tapped.numberOfTapsRequired = 1;
    cell.cellImage.userInteractionEnabled = YES;
    cell.cellImage.tag = indexPath.row;
    [cell.cellImage addGestureRecognizer:tapped];
    
    
    cell.cellImage.alpha = 0;
    cell.cellTimeLabel.alpha = 0;
    cell.cellImage.layer.cornerRadius = 10.0f;
    cell.cellImage.clipsToBounds = YES;
    [UIView beginAnimations:@"fadeIn" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.3];
    
    NSString *user = snap.sm_owner;
    NSArray *components = [user componentsSeparatedByString:@"/"];
    NSString *facebookUserId = [components objectAtIndex:1];
    NSString *facebookPicURL = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture", facebookUserId];
    
    [cell.cellProfileImage setImageWithURL:[NSURL URLWithString:facebookPicURL] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    cell.cellProfileLabel.text = snap.creator;
    
    
    [cell.cellImage setImageWithURL:[NSURL URLWithString:snap.photo] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    
    cell.cellImage.alpha = 1;
    cell.cellTimeLabel.alpha = 1;
    [UIView commitAnimations];
    
    return cell;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    return YES;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return CELL_HEIGHT;
}

#pragma mark UIActionSheet delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    //Get the name of the current pressed button
    NSString *buttonTitle = [actionSheet buttonTitleAtIndex:buttonIndex];
    if  ([buttonTitle isEqualToString:@"Logout"]) {
        [[[[self appDelegate] client] session] clearSessionInfo];
        
        
        [[[self appDelegate] client] logoutOnSuccess:^(NSDictionary *result) {
            [FBSession.activeSession closeAndClearTokenInformation];
            [self dismissViewControllerAnimated:YES completion:nil];
        } onFailure:^(NSError *error) {
            DLog(@"Error trying to logout: %@", error);
            [self dismissViewControllerAnimated:YES completion:nil];
        }];
    }
}

#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)loadPhotos {
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    
    // We'll be performing a fetch request on the Snap entity
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Snap"
                                              inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    
    // Edit the sort key as appropriate.
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"createddate" ascending:NO];
    NSArray *sortDescriptors = [NSArray arrayWithObjects:sortDescriptor, nil];
    
    [fetchRequest setSortDescriptors:sortDescriptors];
    
    if (self.isUserProfile) {
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSString *sm_owner = [defaults objectForKey:SNAPSTACK_SM_OWNER];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"sm_owner == %@", sm_owner];
        [fetchRequest setPredicate:predicate];
        
        [context executeFetchRequest:fetchRequest onSuccess:^(NSArray *results) {
            self.userPhotos = [NSMutableArray arrayWithArray:results];
            [self.tableView reloadData];
            
        } onFailure:^(NSError *error) {
            DLog(@"Error downloading photos in profile view: %@", error);
            
        }];
        
    }
    else {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"sm_owner == %@", self.user];
        [fetchRequest setPredicate:predicate];
        
        [context executeFetchRequest:fetchRequest onSuccess:^(NSArray *results) {
            self.userPhotos = [NSMutableArray arrayWithArray:results];
            [self.tableView reloadData];
            
        } onFailure:^(NSError *error) {
            DLog(@"Error downloading photos in profile view: %@", error);
            
        }];
    }
}

- (IBAction)dismiss:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)logOut:(id)sender {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:@"Are you sure you want to logout?"
                                  delegate:self
                                  cancelButtonTitle:@"Cancel"
                                  destructiveButtonTitle:@"Logout"
                                  otherButtonTitles:nil];
    [actionSheet setActionSheetStyle:UIActionSheetStyleBlackOpaque];
    [actionSheet showInView:self.view];
}

- (void)loadPhotoView :(id) sender {
    UITapGestureRecognizer *gesture = (UITapGestureRecognizer *) sender;
    
    MOBViewPhotoViewController *viewPhotoViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewPhotoViewController"];
    viewPhotoViewController.title = @"View Photo";
    Snap *snap = [self.userPhotos objectAtIndex:gesture.view.tag];
    viewPhotoViewController.objectID = snap.objectID;
    
    [self.navigationController pushViewController:viewPhotoViewController animated:YES];
}

- (void)loadFacebookProfile {
    
    NSArray *components = [self.user componentsSeparatedByString:@"/"];
    NSString *facebookUserId = [components objectAtIndex:1];
    
    NSURL *facebookAppUrl = [NSURL URLWithString:[NSString stringWithFormat:@"fb://profile/%@", facebookUserId]];
    NSURL *facebookWebUrl = [NSURL URLWithString:[NSString stringWithFormat:@"https://www.facebook.com/profile.php?id=%@", facebookUserId]];
    
    if ([[UIApplication sharedApplication] canOpenURL:facebookAppUrl]) {
        [[UIApplication sharedApplication] openURL:facebookAppUrl];
    }
    else {
        [[UIApplication sharedApplication] openURL:facebookWebUrl];
    }
}

- (void)viewDidUnload {
    [self setTableView:nil];
    [super viewDidUnload];
}
@end
