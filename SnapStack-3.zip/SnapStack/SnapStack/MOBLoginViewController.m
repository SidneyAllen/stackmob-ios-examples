/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <FacebookSDK/FacebookSDK.h>
#import "MOBLoginViewController.h"
#import "MOBAppDelegate.h"
#import "MOBTabBarController.h"

@interface MOBLoginViewController ()

@end

@implementation MOBLoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES];
    
    [self.view setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.activated = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Facebook methods

- (void)createUser {
    
    [[[self appDelegate] client] createUserWithFacebookToken:[NSString stringWithFormat:@"%@",FBSession.activeSession.accessToken] onSuccess:^(NSDictionary *result) {
        DLog(@"Created user with Facebook token");
        [self welcomeUser];
        
        [self.activityIndicator removeFromSuperview];
        self.activated = NO;
        
    } onFailure:^(NSError *error) {
        // User already exists with this FB Token, call Login method
        DLog(@"Error creating a user with Facebook token: %@", error);
        [self loginUser];
    }];
}

- (void)loginUser {
    
    [[[self appDelegate] client] loginWithFacebookToken:FBSession.activeSession.accessToken onSuccess:^(NSDictionary *result) {
        DLog(@"Logged in with Facebook token");
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSString *sm_owner = [result objectForKey:@"sm_owner"];
        [defaults setObject:sm_owner forKey:SNAPSTACK_SM_OWNER];
        [defaults synchronize];
        
        // User is logged in
        MOBTabBarController *tabBarController = [self.storyboard instantiateViewControllerWithIdentifier:@"TabBarController"];
        
        [self.navigationController pushViewController:tabBarController animated:YES];
        
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound];
        
        [self.activityIndicator removeFromSuperview];
        self.activated = NO;
        
        
    } onFailure:^(NSError *error) {
        
        DLog(@"Error logging in with Facebook token: %@", error);
        
        
        // Show the result in an alert
        [[[UIAlertView alloc] initWithTitle:@"Oops!"
                                    message:@"Couldn't login with Facebook"
                                   delegate:self
                          cancelButtonTitle:@"OK"
                          otherButtonTitles:nil]
         show];
        
        [self.activityIndicator removeFromSuperview];
        self.activated = NO;
    }];
}

- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error
{
    switch (state) {
        case FBSessionStateOpen:
            [self createUser];
            break;
        case FBSessionStateClosed:
            [FBSession.activeSession closeAndClearTokenInformation];
            [self.activityIndicator removeFromSuperview];
            self.activated = NO;
            // User is logged out
            break;
        case FBSessionStateClosedLoginFailed:
            [FBSession.activeSession closeAndClearTokenInformation];
            [self.activityIndicator removeFromSuperview];
            self.activated = NO;
            break;
        default:
            break;
    }
    
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Error"
                                  message:error.localizedDescription
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
}


#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (IBAction)loginWithFacebook:(id)sender {
    
    if (!self.activated) {
        
        self.activated = YES;
        
        self.activityIndicator = [self showActivityIndicatorOnView:self.view];
        
        NSArray *permissions = [[NSArray alloc] initWithObjects:@"email", nil];
        [FBSession openActiveSessionWithReadPermissions:permissions allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState status, NSError *error) {
            [self sessionStateChanged:session state:status error:error];
        }];
    }
}

- (void)welcomeUser {
    
    [[[self appDelegate] client] loginWithFacebookToken:FBSession.activeSession.accessToken onSuccess:^(NSDictionary *theResult) {
        DLog(@"Logged in with Facebook token");
        // User is logged in
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSString *sm_owner = [theResult objectForKey:@"sm_owner"];
        [defaults setObject:sm_owner forKey:SNAPSTACK_SM_OWNER];
        [defaults synchronize];
        
        MOBTabBarController *tabBarController = [self.storyboard instantiateViewControllerWithIdentifier:@"TabBarController"];
        
        [self.navigationController pushViewController:tabBarController animated:YES];
        
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound];
        
        [self.activityIndicator removeFromSuperview];
        self.activated = NO;
        
        [[[self appDelegate] client] getLoggedInUserFacebookInfoWithOnSuccess:^(NSDictionary *result) {
            
            NSString *name = [result objectForKey:@"first_name"];
            NSString *email = [result objectForKey:@"email"];
            NSString *subject = @"Welcome to SnapStack!";
            NSString *text = [NSString stringWithFormat:@"Hi %@,\n\nThanks for joining SnapStack! We're happy to have you using our product, and we promise we'll never use your pictures as ads. Enjoy snapping photos with SnapStack!\n\nSincerely,\n\nThe SnapStack team", name];
            
            
            SMCustomCodeRequest *customCodeRequest = [[SMCustomCodeRequest alloc]
                                                      initPostRequestWithMethod:(NSString *)@"sendgrid/email"
                                                      body:(NSString *) nil];
            
            NSArray *emails = [[NSArray alloc]
                               initWithObjects:email, nil];
            
            //convert object to data
            NSDictionary *dic = [[NSDictionary alloc]
                                 initWithObjectsAndKeys:
                                 emails, @"emails",
                                 subject, @"subject",
                                 text, @"text",
                                 @"support@getsnapstack.com", @"from",
                                 nil];
            
            NSError* customCodeError;
            NSData* jsonData = [NSJSONSerialization
                                dataWithJSONObject:dic
                                options:0 error:&customCodeError];
            
            [customCodeRequest setRequestBody:[[NSString alloc]
                                               initWithData:jsonData
                                               encoding:NSUTF8StringEncoding]];
            
            [[[SMClient defaultClient] dataStore]
             performCustomCodeRequest:customCodeRequest
             onSuccess:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {
                 
                 DLog(@"Successfully performed Custom Code method");
                 
             } onFailure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON){
                 
                 DLog(@"Error performing Custom Code method: %@", error);
                 
             }];
        } onFailure:^(NSError *error) {
            
            DLog(@"Error getting user Facebook info: %@", error);
        }];
    } onFailure:^(NSError *error) {
        
        DLog(@"Error logging in with Facebook token: %@", error);
    }];
}

- (UIActivityIndicatorView *)showActivityIndicatorOnView:(UIView*)aView
{
    CGSize viewSize = aView.bounds.size;
    
    // create new dialog box view and components
    UIActivityIndicatorView *activityIndicatorView = [[UIActivityIndicatorView alloc]
                                                      initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    
    // other size? change it
    activityIndicatorView.bounds = CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height );
    activityIndicatorView.hidesWhenStopped = YES;
    
    // display it in the center of your view
    activityIndicatorView.center = CGPointMake(viewSize.width / 2.0, viewSize.height / 1.5);
    
    [aView addSubview:activityIndicatorView];
    
    [activityIndicatorView startAnimating];
    
    return activityIndicatorView;
}

@end
