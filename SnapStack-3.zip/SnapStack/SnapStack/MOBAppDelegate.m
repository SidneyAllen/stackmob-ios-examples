/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "MOBAppDelegate.h"
#import "MOBLoginViewController.h"
#import "MOBTabBarController.h"
#import "MOBViewPhotoViewController.h"
#import "StackMobPush.h"
#import <FacebookSDK/FacebookSDK.h>

@implementation MOBAppDelegate

@synthesize client = _client;
@synthesize coreDataStore = _coreDataStore;
@synthesize pushClient = _pushClient;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize viewController = _viewController;
@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    SM_CACHE_ENABLED = YES;
    
    self.client = [[SMClient alloc] initWithAPIVersion:@"1" publicKey:@"YOUR_PUBLIC_KEY"];
    self.coreDataStore = [self.client coreDataStoreWithManagedObjectModel:self.managedObjectModel];
    
    self.pushClient = [[SMPushClient alloc] initWithAPIVersion:@"1" publicKey:@"YOUR_PUBLIC_KEY"
                                                    privateKey:@"YOUR_PRIVATE_KEY"];
    
    // Setup navigation bar appearance
    [self setNavigationBarAppearance];
    
    // Grab the storyboard
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard"
                                                         bundle: nil];
    
    // Initialize the sign in view as the root controller
    MOBLoginViewController *loginViewController = [storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:loginViewController];
    navigationController.navigationBarHidden = YES;
    
    if ([self.client isLoggedIn]) {
        // If the user is signed in, go directly to the main view
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound];
        
        [FBSession openActiveSessionWithReadPermissions:nil allowLoginUI:NO completionHandler:^(FBSession *session, FBSessionState status, NSError *error){
            
            if (error) {
                DLog(@"Error opening active Facebook session: %@", error);
            }
        }];
        
        MOBTabBarController *tabBarController = [storyboard instantiateViewControllerWithIdentifier:@"TabBarController"];
        tabBarController.navigationItem.hidesBackButton = YES;
        [navigationController pushViewController:tabBarController animated:NO];
        self.viewController = navigationController;
        [self.window setRootViewController:self.viewController];
        
    }
    else
    {
        DLog(@"No logged in user present");
        // Otherwise, go to the sign in view
        self.viewController = navigationController;
        [self.window setRootViewController:self.viewController];
    }
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    
    NSString *token = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    token = [[token componentsSeparatedByString:@" "] componentsJoinedByString:@""];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *sm_owner = [defaults objectForKey:SNAPSTACK_SM_OWNER];
    NSArray *components = [sm_owner componentsSeparatedByString:@"/"];
    NSString *userId = [components objectAtIndex:1];
    
    [self.pushClient registerDeviceToken:token withUser:userId onSuccess:^{
        
        DLog(@"Successfully registered device for push notifications");
    } onFailure:^(NSError *error) {
        
        DLog(@"Error registering for push notifications: %@", error);
    }];
    
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {
    DLog(@"Error in registration. Error: %@", err);
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    
    
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateInactive) {
        
        NSManagedObjectContext *context = [self.coreDataStore contextForCurrentThread];
        
        // We'll be performing a retch request on the Snap entity
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"Snap"
                                                  inManagedObjectContext:context];
        [fetchRequest setEntity:entity];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"snapId == %@", [userInfo objectForKey:@"snapId"]];
        [fetchRequest setPredicate:predicate];
        
        [context executeFetchRequest:fetchRequest onSuccess:^(NSArray *results) {
            Snap *snap = [results objectAtIndex:0];
            
            UINavigationController *navController = (UINavigationController *)self.window.rootViewController;
            
            // Grab the storyboard
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard"
                                                                 bundle: nil];
            
            MOBViewPhotoViewController *viewPhotoViewController = [storyboard instantiateViewControllerWithIdentifier:@"ViewPhotoViewController"];
            viewPhotoViewController.title = @"View Photo";
            
            viewPhotoViewController.objectID = snap.objectID;
            
            [navController pushViewController:viewPhotoViewController animated:NO];
        } onFailure:^(NSError *error) {
            
            DLog(@"Error opening view controller from push notification: %@", error);
        }];
    }
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    [FBSession.activeSession handleDidBecomeActive];
    
    // Clear all notifications
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber: 1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber: 0];
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    
    [FBSession.activeSession close];
}

- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    // attempt to extract a token from the url
    return [FBSession.activeSession handleOpenURL:url];
}

#pragma mark - Core Data methods

- (NSManagedObjectModel *)managedObjectModel
{
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Model" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

#pragma mark - Custom methods

// Many thanks to WrightsCS at StackOverflow for this method: http://stackoverflow.com/questions/6207329/how-to-set-hex-color-code-for-background
- (UIColor*)colorWithHexString:(NSString*)hex
{
    
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

#pragma mark - Private Methods

- (void)setNavigationBarAppearance {
    
    UIImage *navigationBarBackground = [[UIImage imageNamed:@"NavigationBarBackground"] stretchableImageWithLeftCapWidth:5.0 topCapHeight:0.0];
    
    [[UINavigationBar appearance] setBackgroundImage:navigationBarBackground forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setTintColor:[UIColor clearColor]];
}


@end
