/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <QuartzCore/QuartzCore.h>
#import <MobileCoreServices/UTCoreTypes.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "MOBTabBarController.h"
#import "MOBSharePhotoViewController.h"
#import "MOBProfileViewController.h"
#import "MOBMapViewController.h"
#import "MOBAppDelegate.h"
#import "SEFilterControl.h"

@interface MOBTabBarController ()

@property (strong, nonatomic) UIView *filterView;
@property (assign) double distance;

@end

@implementation MOBTabBarController

-(void)viewWillAppear:(BOOL)animated {
    if (![[[self appDelegate] client] isLoggedIn]) {
        [self.navigationController popToRootViewControllerAnimated:NO];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - ImagePickerController delegate

- (void)image:(UIImage *)image
finishedSavingWithError:(NSError *)error
  contextInfo:(void *)contextInfo
{
    if (error) {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle: @"Save failed"
                              message: @"Failed to save image"
                              delegate: nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
        [alert show];
    }
}

#pragma mark - DLCImagePickerController

- (void)imagePickerControllerDidCancel:(DLCImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(DLCImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:NO];
    if (info) {
        
        UIImage *image = [UIImage imageWithData:[info objectForKey:@"data"]];
        
        
        
        MOBSharePhotoViewController *sharePhotoViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SharePhotoViewController"];
        sharePhotoViewController.title = @"Share Photo";
        sharePhotoViewController.image = image;
        
        
        
        [picker.navigationController pushViewController:sharePhotoViewController animated:TRUE];
        
        UIImageWriteToSavedPhotosAlbum(image,
                                       self,
                                       @selector(image:finishedSavingWithError:contextInfo:),
                                       nil);
    }
}

#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)loadObjects {
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    
    // We'll be performing a retch request on the Snap entity
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Snap"
                                              inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    
    // Edit the sort key as appropriate.
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"createddate" ascending:NO];
    NSArray *sortDescriptors = [NSArray arrayWithObjects:sortDescriptor, nil];
    
    [fetchRequest setSortDescriptors:sortDescriptors];
    
    [SMGeoPoint getGeoPointForCurrentLocationOnSuccess:^(SMGeoPoint *geoPoint) {
        
        SMPredicate *predicate = [SMPredicate predicateWhere:@"location" isWithin:self.distance milesOfGeoPoint:geoPoint];
        [fetchRequest setPredicate:predicate];
        
        [context executeFetchRequest:fetchRequest onSuccess:^(NSArray *results) {
            
            DLog(@"Success performing query for objects");
            
            NSMutableArray *array = [NSMutableArray array];
            for (NSManagedObject *result in results) {
                [array addObject:result.objectID];
            }
            
            NSDictionary *userInfo = [NSDictionary dictionaryWithObject:[NSArray arrayWithArray:array] forKey:@"objects"];
            NSNotification *notification = [NSNotification notificationWithName:OBJECTS_LOADED object:nil userInfo:userInfo];
            [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationNoCoalescing forModes:nil];
            
        } onFailure:^(NSError *error) {
            
            DLog(@"Error performing query for objects: %@", error);
            
            NSNotification *notification = [NSNotification notificationWithName:OBJECTS_LOADED object:nil];
            [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationNoCoalescing forModes:nil];
            
        }];
        
    } onFailure:^(NSError *error) {
        DLog(@"Error with geopoint: %@", error);
        
        NSNotification *notification = [NSNotification notificationWithName:OBJECTS_LOADED object:nil];
        [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationNoCoalescing forModes:nil];
    }];
}

- (UIColor*)colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

- (IBAction)showCamera:(id)sender {
    DLog(@"camera");
    
    if (![sender isHighlighted]) {
        [sender setImage:[UIImage imageNamed:@"CameraButton"] forState:UIControlStateNormal];
        [sender setSelected:NO];
    }else {
        [sender setImage:[UIImage imageNamed:@"CameraButtonSelected"] forState:UIControlStateSelected|UIControlStateHighlighted];
        [sender setSelected:YES];
    }
    
    DLCImagePickerController *picker = [[DLCImagePickerController alloc] init];
    picker.delegate = self;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:picker];
    navigationController.navigationBarHidden = YES;
    [self presentViewController:navigationController animated:YES completion:nil];
}

- (IBAction)showProfile:(id)sender {
    
    MOBProfileViewController *profileViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    profileViewController.title = @"Profile";
    profileViewController.isUserProfile = YES;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:profileViewController];
    
    
    [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)filterValueChanged:(SEFilterControl *) sender{
    DLog(@"%@", [NSString stringWithFormat:@"%d", sender.SelectedIndex]);
    
    switch (sender.SelectedIndex) {
        case 0:
            self.distance = 2.0;
            break;
        case 1:
            self.distance = 5.0;
            break;
        case 2:
            self.distance = 10.0;
            break;
        case 3:
            self.distance = 25.0;
            break;
        case 4:
            self.distance = 50.0;
            break;
        default:
            break;
    }
}

- (void)showFilterView {
    
    if (self.filterView.alpha == 0) {
        
        [UIView beginAnimations:@"fadeIn" context:nil];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        [UIView setAnimationDuration:0.3];
        
        self.filterView.alpha = 1;
        
        [UIView commitAnimations];
    }
    else {
        [self hideFilterView];
    }
}

- (void)hideFilterView {
    
    if (self.filterView.alpha == 1) {
        
        [UIView beginAnimations:@"fadeOut" context:nil];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        [UIView setAnimationDuration:0.3];
        
        self.filterView.alpha = 0;
        
        [UIView commitAnimations];
    }
}


- (void)setupFilterView {
    
    // Set the initial distance for the filter view
    self.distance = 2.0;
    
    // Contruct the filter view
    self.filterView = [[UIView alloc] initWithFrame:CGRectMake(10, 10, 300, 70)];
    UIImageView *filterBackground = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 300, 70)];
    [filterBackground setImage:[UIImage imageNamed:@"TabBarBackground"]];
    [self.filterView addSubview:filterBackground];
    
    // Construct the filter control
    SEFilterControl *filter = [[SEFilterControl alloc]initWithFrame:CGRectMake(10, 5, 280, 70) Titles:[NSArray arrayWithObjects:@"2 miles", @"5 miles", @"10 miles", @"25 miles", @"50 miles", nil]];
    [filter setTitlesFont:[UIFont boldSystemFontOfSize:12]];
    [filter setTitlesColor:[UIColor whiteColor]];
    [filter setProgressColor:[self colorWithHexString:FILTER_COLOR]];
    
    // Add the filter control to the filter view
    [self.filterView addSubview:filter];
    [filter addTarget:self action:@selector(filterValueChanged:) forControlEvents:UIControlEventValueChanged];
    self.filterView.layer.cornerRadius = 10.0f;
    self.filterView.clipsToBounds = YES;
    
    // Add the filter view to the entire view, and make it invisible
    [self.view addSubview:self.filterView];
    self.filterView.alpha = 0;
    
    // Register for notifications to hide the filter view
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hideFilterView) name:@"viewTouched" object:nil];
}

- (void)setupTabBar {
    
    // Set the TabBar background
    UITabBar *tabBar = self.tabBar;
    [tabBar setBackgroundImage:[UIImage imageNamed:@"TabBarBackground"]];
    UIImage *selectedItemBackground = [[UIImage imageNamed:@"TabBarBackground"] stretchableImageWithLeftCapWidth:6.0 topCapHeight:0.0];
    [tabBar setSelectionIndicatorImage:selectedItemBackground];
    
    // Draw a shadow offset on the TabBar
    tabBar.layer.shadowColor = [[UIColor blackColor] CGColor];
    tabBar.layer.shadowOffset = CGSizeMake(0.0, -10);
    tabBar.layer.shadowOpacity = 0.20;
    tabBar.layer.masksToBounds = NO;
    tabBar.layer.shouldRasterize = YES;
    
    // Set selection images for Feed tab
    UITabBarItem *item0 = [tabBar.items objectAtIndex:0];
    [item0 setFinishedSelectedImage:[UIImage imageNamed:@"TabBarFeedButtonSelected"] withFinishedUnselectedImage:[UIImage imageNamed:@"TabBarFeedButton"]];
    
    
    // Disable the tabBarItem hidden by the Camera button
    UITabBarItem *item1 = [tabBar.items objectAtIndex:1];
    [item1 setEnabled:FALSE];
    
    // Set selection images for Map tab
    UITabBarItem *item2 = [tabBar.items objectAtIndex:2];
    [item2 setFinishedSelectedImage:[UIImage imageNamed:@"TabBarMapButtonSelected"] withFinishedUnselectedImage:[UIImage imageNamed:@"TabBarMapButton"]];
    
    // Add Camera button to TabBar
    UIButton *cameraButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [cameraButton setFrame:CGRectMake(110, 3.0, 100, 44)];
    [cameraButton setImage:[UIImage imageNamed:@"CameraButton"] forState:UIControlStateNormal];
    [cameraButton setImage:[UIImage imageNamed:@"CameraButtonSelected"] forState:UIControlStateSelected|UIControlStateHighlighted];
    [cameraButton addTarget:self action:@selector(showCamera:) forControlEvents:UIControlEventTouchUpInside];
    [self.tabBar addSubview:cameraButton];
}

- (void)setupNavigationBar {
    
    // Make sure Navigation Bar is visible
    [self.navigationController setNavigationBarHidden:NO];
    
    // SnapStack logo for navigation bar
    UIImage *logo = [UIImage imageNamed:@"logo.png"];
    UIImageView *snapStackLogo = [[UIImageView alloc] initWithImage:logo];
    snapStackLogo.frame = CGRectMake(0, 0, logo.size.width, logo.size.height);
    self.navigationItem.titleView =snapStackLogo;
    
    
    // Construct profile bar button item
    UIBarButtonItem *profile = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"ProfileButton"] style:UIBarButtonItemStyleBordered target:self action:@selector(showProfile:)];
    [profile setTintColor:[UIColor clearColor]];
    self.navigationItem.leftBarButtonItem = profile;
    
    // Construct filter bar button item
    UIBarButtonItem *distance = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"RadiusButton"] style:UIBarButtonItemStyleBordered target:self action:@selector(showFilterView)];
    [distance setTintColor:[UIColor clearColor]];
    self.navigationItem.rightBarButtonItem = distance;
}

- (void)setupView {
    
    [self setDelegate:self];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadObjects) name:LOAD_OBJECTS object:nil];
    
    [self setupNavigationBar];
    [self setupTabBar];
    [self setupFilterView];
}


@end
