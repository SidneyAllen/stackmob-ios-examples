/*
 * Copyright 2012-2013 StackMob
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <SDWebImage/UIImageView+WebCache.h>
#import <QuartzCore/QuartzCore.h>
#import <FacebookSDK/FacebookSDK.h>
#import "MOBFeedViewController.h"
#import "MOBTableViewCell.h"
#import "MOBViewPhotoViewController.h"
#import "MOBProfileViewController.h"
#import "MOBTabBarController.h"
#import "MOBAppDelegate.h"

@interface MOBFeedViewController ()

@end

@implementation MOBFeedViewController

@synthesize feedPhotos;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.pullToRefreshView = [[SSPullToRefreshView alloc] initWithScrollView:self.tableView delegate:self];
    
    self.timeIntervalFormatter = [[TTTTimeIntervalFormatter alloc] init];
    
    [self.view setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadPhotos:) name:OBJECTS_LOADED object:nil];
    
    [self.pullToRefreshView startLoadingAndExpand:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"viewTouched" object:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [feedPhotos count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    // Configure the cell...
    
    MOBTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (cell == nil) {
        
        NSArray *bundle = [[NSBundle mainBundle] loadNibNamed:@"MOBTableViewCell" owner:self options:nil];
        for (id nib in bundle) {
            if ([nib isKindOfClass:[MOBTableViewCell class]]) {
                cell = (MOBTableViewCell *)nib;
                break;
            }
        }
    }
    
    [cell setBackgroundColor:[[self appDelegate] colorWithHexString:BACKGROUND_COLOR]];
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    
    NSManagedObjectID *objectID = [self.feedPhotos objectAtIndex:indexPath.row];
    
    Snap *snap = (Snap *)[context objectWithID:objectID];
    
    NSTimeInterval utc = [snap.createddate unsignedLongLongValue]/1000;
    NSTimeInterval interval = [[NSDate dateWithTimeIntervalSince1970:utc] timeIntervalSinceDate:[NSDate date]];
    cell.cellTimeLabel.text = [self.timeIntervalFormatter stringForTimeInterval:interval];
    
    UITapGestureRecognizer *pictureTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadPhotoView:)];
    pictureTap.numberOfTapsRequired = 1;
    cell.cellImage.userInteractionEnabled = YES;
    cell.cellImage.tag = indexPath.row;
    [cell.cellImage addGestureRecognizer:pictureTap];
    
    
    UITapGestureRecognizer *profileTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadProfileView:)];
    profileTap.numberOfTapsRequired = 1;
    cell.cellProfileImage.userInteractionEnabled = YES;
    cell.cellProfileImage.tag = indexPath.row;
    [cell.cellProfileImage addGestureRecognizer:profileTap];
    
    
    cell.cellImage.alpha = 0;
    cell.cellTimeLabel.alpha = 0;
    cell.cellImage.layer.cornerRadius = 10.0f;
    cell.cellImage.clipsToBounds = YES;
    [UIView beginAnimations:@"fadeIn" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.3];
    
    NSString *user = snap.sm_owner;
    NSArray *components = [user componentsSeparatedByString:@"/"];
    NSString *facebookUserId = [components objectAtIndex:1];
    NSString *facebookPicURL = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture", facebookUserId];
    
    [cell.cellProfileImage setImageWithURL:[NSURL URLWithString:facebookPicURL] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    cell.cellProfileLabel.text = snap.creator;
    
    
    [cell.cellImage setImageWithURL:[NSURL URLWithString:snap.photo] placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    
    cell.cellImage.alpha = 1;
    cell.cellTimeLabel.alpha = 1;
    [UIView commitAnimations];
    
    return cell;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    return YES;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return CELL_HEIGHT;
}


#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)pullToRefreshViewDidStartLoading:(SSPullToRefreshView *)view {
    
    [self.pullToRefreshView startLoading];
    
    NSNotification *notification = [NSNotification notificationWithName:LOAD_OBJECTS object:nil];
    [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationCoalescingOnName forModes:nil];
}

- (void)loadPhotos:(NSNotification *)notification {
    
    NSDictionary *userInfo = notification.userInfo;
    self.feedPhotos = [userInfo objectForKey:@"objects"];
    [self.tableView reloadData];
    [self.pullToRefreshView finishLoading];
}

- (void)loadPhotoView:(id) sender {
    UITapGestureRecognizer *gesture = (UITapGestureRecognizer *) sender;
    
    MOBViewPhotoViewController *viewPhotoViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewPhotoViewController"];
    viewPhotoViewController.title = @"View Photo";
    
    viewPhotoViewController.objectID = [self.feedPhotos objectAtIndex:gesture.view.tag];
    
    [self.tabBarController.navigationController pushViewController:viewPhotoViewController animated:YES];
}

- (void)loadProfileView:(id) sender {
    
    UITapGestureRecognizer *gesture = (UITapGestureRecognizer *) sender;
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    
    NSManagedObjectID *objectID = [self.feedPhotos objectAtIndex:gesture.view.tag];
    
    Snap *snap = (Snap *)[context objectWithID:objectID];
    
    NSString *user = snap.sm_owner;
    
    MOBProfileViewController *profileViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    profileViewController.title = @"Profile";
    
    profileViewController.isUserProfile = NO;
    profileViewController.user = user;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:profileViewController];
    
    
    [self presentViewController:navigationController animated:YES completion:nil];
}

@end
