//
//  MOBTabBarController.h
//  ShutterMob
//
//  Created by Carl Atupem on 1/8/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
#import "StackMob.h"

@interface MOBTabBarController : UITabBarController


@end
