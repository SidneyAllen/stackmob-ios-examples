//
//  MOBProfileViewController.m
//  ShutterMob
//
//  Created by Carl Atupem on 1/8/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import "MOBProfileViewController.h"
#import "MOBAppDelegate.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface MOBProfileViewController ()

@end

@implementation MOBProfileViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.client = [[self appDelegate] client];
    
    [self.client getLoggedInUserFacebookInfoWithOnSuccess:^(NSDictionary *result) {
        
        self.profileLabel.text = [result objectForKey:@"name"];
        
        
        NSString *facebookUserId  = [result objectForKey:@"id"];
        NSString *facebookPicURL = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture?type=normal", facebookUserId];
        
        [self.profileImage setImageWithURL:[NSURL URLWithString:facebookPicURL]];
        
    } onFailure:^(NSError *error) {
        
        NSLog(@"Error getting user Facebook info: %@", error);
        
    }];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (IBAction)dismiss:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)signOut:(id)sender {
    
    [[[self appDelegate] client] logoutOnSuccess:^(NSDictionary *result) {
        [FBSession.activeSession closeAndClearTokenInformation];
        [self dismissViewControllerAnimated:YES completion:nil];
    } onFailure:^(NSError *error) {
        
    }];
} 

@end
