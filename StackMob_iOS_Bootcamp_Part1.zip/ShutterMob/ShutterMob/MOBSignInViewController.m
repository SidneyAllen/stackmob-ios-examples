//
//  MOBSignInViewController.m
//  ShutterMob
//
//  Created by Carl Atupem on 1/8/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import "MOBSignInViewController.h"
#import "MOBAppDelegate.h"
#import "MOBTabBarController.h"

@interface MOBSignInViewController ()

@end

@implementation MOBSignInViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.client = [self.appDelegate client];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Facebook methods

- (void)createUser {
    
    [self.client createUserWithFacebookToken:[NSString stringWithFormat:@"%@",FBSession.activeSession.accessToken] onSuccess:^(NSDictionary *result) {
        NSLog(@"Successfully created a user with Facebook token: %@", result);
        
        [self welcomeUser];
    } onFailure:^(NSError *error) {
        NSLog(@"Error creating a user with Facebook token: %@", error);
        // User already exists with this FB Token, call Login method
        if (error.code == 401) {
            [self loginUser];
        }
    }];
}

- (void)loginUser {
    
    [self.client loginWithFacebookToken:FBSession.activeSession.accessToken onSuccess:^(NSDictionary *result) {
        NSLog(@"Logged in with Facebook token");
        // User is logged in
        
        MOBTabBarController *tabBarController = [self.storyboard instantiateViewControllerWithIdentifier:@"TabBarController"];
        
        [self.navigationController pushViewController:tabBarController animated:YES];
        
        
    } onFailure:^(NSError *error) {
        NSLog(@"Error logging in with Facebook token: %@", error);
    }];
}


- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error
{
    switch (state) {
        case FBSessionStateOpen:
            [self createUser];
            break;
        case FBSessionStateClosed:
            [FBSession.activeSession closeAndClearTokenInformation];
            // User is logged out
            break;
        case FBSessionStateClosedLoginFailed:
            [FBSession.activeSession closeAndClearTokenInformation];
            break;
        default:
            break;
    }
    
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Error"
                                  message:error.localizedDescription
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
}


#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (IBAction)signInWithFacebook:(id)sender {
    
    NSArray *permissions = [[NSArray alloc] initWithObjects:@"email", nil];
    [FBSession openActiveSessionWithReadPermissions:permissions allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState status, NSError *error) {
        [self sessionStateChanged:session state:status error:error];
    }];
}

- (void) welcomeUser {
    
    [self.client loginWithFacebookToken:FBSession.activeSession.accessToken onSuccess:^(NSDictionary *result) {
        NSLog(@"Logged in with Facebook token");
        // User is logged in
        
        MOBTabBarController *tabBarController = [self.storyboard instantiateViewControllerWithIdentifier:@"TabBarController"];
        
        [self.navigationController pushViewController:tabBarController animated:YES];
        
        [self.client getLoggedInUserFacebookInfoWithOnSuccess:^(NSDictionary *result) {
            
            NSString *name = [result objectForKey:@"first_name"];
            NSString *email = [result objectForKey:@"email"];
            NSString *subject = @"Welcome to ShutterMob!";
            NSString *text = [NSString stringWithFormat:@"Hi %@,\n\nThanks for joining ShutterMob! We're happy to have you using our product, and we promise we'll never use your pictures as ads. Enjoy snapping photos with ShutterMob!\n\nSincerely,\n\nThe ShutterMob team", name];
            
            
            SMCustomCodeRequest *request = [[SMCustomCodeRequest alloc]
                                            initPostRequestWithMethod:(NSString *)@"sendgrid/email"
                                            body:(NSString *) nil];
            
            NSArray *emails = [[NSArray alloc]
                               initWithObjects:email, nil];
            
            //convert object to data
            NSDictionary *dic = [[NSDictionary alloc]
                                 initWithObjectsAndKeys:
                                 emails, @"emails",
                                 subject, @"subject",
                                 text, @"text",
                                 @"support@shuttermob.com", @"from",
                                 nil];
            
            NSError* error;
            NSData* jsonData = [NSJSONSerialization
                                dataWithJSONObject:dic
                                options:0 error:&error];
            
            [request setRequestBody:[[NSString alloc]
                                     initWithData:jsonData
                                     encoding:NSUTF8StringEncoding]];
            
            [[[SMClient defaultClient] dataStore]
             performCustomCodeRequest:request
             onSuccess:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {
                 
                 NSLog(@"Successfully performed Custom Code method");
                 
             } onFailure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON){
                 
                 NSLog(@"Error performing Custom Code method: %@", error);
                 
             }];
            
            
            
        } onFailure:^(NSError *error) {
            
            NSLog(@"Error getting user Facebook info: %@", error);
            
            
        }];
        
        
    } onFailure:^(NSError *error) {
        
        NSLog(@"Error logging in with Facebook token: %@", error);
        
    }];
    
}



@end
