//
//  MOBTabBarController.m
//  ShutterMob
//
//  Created by Carl Atupem on 1/8/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import "MOBTabBarController.h"
#import "MOBAppDelegate.h"
#import "MOBProfileViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface MOBTabBarController ()

@end

@implementation MOBTabBarController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    [self.navigationController setNavigationBarHidden:NO];
    
    UIBarButtonItem *profile = [[UIBarButtonItem alloc] initWithTitle:@"Profile" style:UIBarButtonItemStyleBordered target:self action:@selector(showProfile:)];
    
    self.navigationItem.leftBarButtonItem = profile;
    
    // Draw a shadow offset on the tabBar
    UITabBar *tabBar = self.tabBar;
    tabBar.layer.shadowColor = [[UIColor blackColor] CGColor];
    tabBar.layer.shadowOffset = CGSizeMake(0.0, -10);
    tabBar.layer.shadowOpacity = 0.20;
    tabBar.layer.masksToBounds = NO;
    tabBar.layer.shouldRasterize = YES;
    
    // Disable the tabBarItem hidden by the Camera button
    UITabBarItem *item1 = [tabBar.items objectAtIndex:1];
    [item1 setEnabled:FALSE];
    
    // Add Camera button
    UIButton *cameraButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [cameraButton setFrame:CGRectMake(110, 3.0, 100, 44)];
    [cameraButton addTarget:self action:@selector(showCamera:) forControlEvents:UIControlEventTouchUpInside];
    [self.tabBar addSubview:cameraButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private methods

- (MOBAppDelegate *)appDelegate {
    return (MOBAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (IBAction)showCamera:(id)sender {
    NSLog(@"camera");
    
    
}

- (IBAction)showProfile:(id)sender {
    
    MOBProfileViewController *profileViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    [self presentViewController:profileViewController animated:YES completion:nil];
}


@end
