//
//  MOBProfileViewController.h
//  ShutterMob
//
//  Created by Carl Atupem on 1/8/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
#import "StackMob.h"

@interface MOBProfileViewController : UIViewController
- (IBAction)dismiss:(id)sender;
- (IBAction)signOut:(id)sender;

@property (strong, nonatomic) IBOutlet UIImageView *profileImage;
@property (strong, nonatomic) IBOutlet UILabel *profileLabel;
@property (strong, nonatomic) SMClient *client;

@end
