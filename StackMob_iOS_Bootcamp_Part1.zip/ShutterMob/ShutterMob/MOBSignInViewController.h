//
//  MOBSignInViewController.h
//  ShutterMob
//
//  Created by Carl Atupem on 1/8/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StackMob.h"

@interface MOBSignInViewController : UIViewController

@property (strong, nonatomic) SMClient *client;
- (IBAction)signInWithFacebook:(id)sender;

@end
