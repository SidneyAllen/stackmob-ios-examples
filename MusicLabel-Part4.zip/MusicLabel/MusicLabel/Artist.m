//
//  Artist.m
//  MusicLabel
//
//  Created by Carl Atupem on 12/18/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "Artist.h"
#import "Album.h"
#import "Label.h"


@implementation Artist

@dynamic hometown;
@dynamic name;
@dynamic artistId;
@dynamic albums;
@dynamic label;

@end
