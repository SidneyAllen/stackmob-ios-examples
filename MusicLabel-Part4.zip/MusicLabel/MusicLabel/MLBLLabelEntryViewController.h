//
//  MLBLLabelEntryViewController.h
//  MusicLabel
//
//  Created by Carl Atupem on 12/11/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MLBLLabelEntryViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *labelField;


@end
