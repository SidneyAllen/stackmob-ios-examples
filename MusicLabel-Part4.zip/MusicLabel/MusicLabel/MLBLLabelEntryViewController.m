//
//  MLBLLabelEntryViewController.m
//  MusicLabel
//
//  Created by Carl Atupem on 12/11/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "MLBLLabelEntryViewController.h"
#import "MLBLAppDelegate.h"
#import "StackMob.h"
#import "Label.h"

@interface MLBLLabelEntryViewController ()

@end

@implementation MLBLLabelEntryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    // This will call our 
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"Add" style:UIBarButtonItemStyleBordered target:self action:@selector(addLabel)];
    self.navigationItem.rightBarButtonItem = item;
    
    UIBarButtonItem *item2 = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(dismiss)];
    self.navigationItem.leftBarButtonItem = item2;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - private methods

- (MLBLAppDelegate *)appDelegate {
    return (MLBLAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void) addLabel {
    
    // Grab the context
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    
    // Grab the Label entity
    Label *label = [NSEntityDescription insertNewObjectForEntityForName:@"Label" inManagedObjectContext:context];
    
    label.labelId = [label assignObjectId];
    
    // Set label name
    label.name = self.labelField.text;
    
       
    // Save everything
    [context saveOnSuccess:^{
        NSLog(@"The save was successful!");
    } onFailure:^(NSError *error) {
        NSLog(@"The save wasn't successful: %@", [error localizedDescription]);
    }];

    [self dismiss];
}

- (void) dismiss {

    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
