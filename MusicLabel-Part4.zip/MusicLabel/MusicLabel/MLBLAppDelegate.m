//
//  MLBLAppDelegate.m
//  MusicLabel
//
//  Created by Carl Atupem on 11/2/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "MLBLAppDelegate.h"
#import "StackMob.h"
#import "Label.h"
#import "Artist.h"
#import "Album.h"

@implementation MLBLAppDelegate

@synthesize managedObjectModel = _managedObjectModel;
@synthesize client = _client;
@synthesize coreDataStore = _coreDataStore;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    self.client = [[SMClient alloc] initWithAPIVersion:@"0" publicKey:@"aec66f53-938d-4966-8782-79b9ffd3f519"];
    self.coreDataStore = [self.client coreDataStoreWithManagedObjectModel:self.managedObjectModel];
    
    /* The methods we use in the tutorial. */
    [self create];
    
   
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Saves changes in the application's managed object context before the application terminates.
}

// Returns the managed object model for the application.
// If the model doesn't already exist, it is created from the application's model.
- (NSManagedObjectModel *)managedObjectModel
{
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"MusicLabel" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}


#pragma mark - Private methods

- (void) create {
    // Grab the context
    NSManagedObjectContext *context = [self.coreDataStore contextForCurrentThread];
    
    // Grab the Label entity
    Label *label = [NSEntityDescription insertNewObjectForEntityForName:@"Label" inManagedObjectContext:context];
    
    label.labelId = [label assignObjectId];
    
    // Set label name
    label.name = @"Diplomat Records";
    
    // Create a Date
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY"];
    NSDate *dateFounded = [dateFormatter dateFromString:@"2003"];
    
    // Set the year founded for the label
    label.founded = dateFounded;
    
    // Set the label genre
    label.genre = @"Rap/Hip-hop";
    
    // Insert the Artist entity
    Artist *artist = [NSEntityDescription insertNewObjectForEntityForName:@"Artist" inManagedObjectContext:context];
    
    artist.artistId = [artist assignObjectId];
    
    // Set the artist attributes
    artist.name = @"Cam'Ron";
    artist.hometown = @"Harlem, NY";
    
    // Insert Album entity
    Album *album = [NSEntityDescription insertNewObjectForEntityForName:@"Album" inManagedObjectContext:context];
    
    album.albumId = [album assignObjectId];
    
    // Set album attributes
    album.title = @"Come Home With Me";
    NSDate *releaseDate = [dateFormatter dateFromString:@"2002"];
    album.released = releaseDate;
    
    NSError *error = nil;
    if (![context saveAndWait:&error]) {
        NSLog(@"The save wasn't successful: %@", [error userInfo]);
    } else {
        NSLog(@"Save successful");
    }
    
    // Set relationships
    [label addArtistsObject:artist];
    [artist setLabel:label];
    [artist addAlbumsObject:album];
    [album setArtist:artist];
    
    [context saveOnSuccess:^{
        NSLog(@"Successful relations update");
    } onFailure:^(NSError *error) {
        NSLog(@"Unsuccessful relations update with error %@", error);
    }];
}

- (void) read {
    NSManagedObjectContext *context = [self.coreDataStore contextForCurrentThread];
    
    // Construct a fetch request
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Label"
                                              inManagedObjectContext:context];
    
    [fetchRequest setEntity:entity];
    
    [context executeFetchRequest:fetchRequest onSuccess:^(NSArray *results) {
        for (Label *label in results) {
            // Log the label details
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"YYYY"];
            
            NSLog(@"%@, est. %@ (%@)", label.name, [dateFormatter stringFromDate:label.founded], label.genre);
            
            NSLog(@"\tArtists:");
            NSSet *artists = label.artists;
            for (Artist *artist in artists) {
                // Log the artist details
                NSLog(@"\t\t%@ (%@)", artist.name, artist.hometown);
                
                NSLog(@"\t\t\tAlbums:");
                NSSet *albums = artist.albums;
                for (Album *album in albums) {
                    // Log the album details
                    NSLog(@"\t\t\t\t%@ (%@)", album.title,  [dateFormatter stringFromDate:album.released]);
                }
            }
        }
    } onFailure:^(NSError *error) {
        NSLog(@"Error fetching: %@", error);
    }];
    
    
}

- (void) update {
    // Grab the context
    NSManagedObjectContext *context = [self.coreDataStore contextForCurrentThread];
    
    // Perform fetch request
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Label"
                                              inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    NSError *error = nil;
    NSArray *fetchedObjects = [context executeFetchRequestAndWait:fetchRequest error:&error];
    
    // Date formatter comes in handy
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY"];
    
    // Grab the label
    Label *label = [fetchedObjects objectAtIndex:0];
    
    // Juelz Santana
    Artist *juelz = [NSEntityDescription insertNewObjectForEntityForName:@"Artist" inManagedObjectContext:context];
    
    juelz.artistId = [juelz assignObjectId];
    
    juelz.name = @"Juelz Santana";
    juelz.hometown = @"Harlem, NY";
    
    // Juelz Santana albums
    Album *juelzAlbum = [NSEntityDescription insertNewObjectForEntityForName:@"Album" inManagedObjectContext:context];
    
    juelzAlbum.albumId = [juelzAlbum assignObjectId];
    
    juelzAlbum.title = @"From Me to U";
    juelzAlbum.released = [dateFormatter dateFromString:@"2003"];
    
    Album *juelzAlbum2 = [NSEntityDescription insertNewObjectForEntityForName:@"Album" inManagedObjectContext:context];
    
    juelzAlbum2.albumId = [juelzAlbum2 assignObjectId];
    
    juelzAlbum2.title = @"What The Game's Been Missing!";
    juelzAlbum2.released = [dateFormatter dateFromString:@"2005"];
    
    
    // Jim Jones
    Artist *jimmy = [NSEntityDescription insertNewObjectForEntityForName:@"Artist" inManagedObjectContext:context];
    
    jimmy.artistId = [jimmy assignObjectId];
    
    jimmy.name = @"Jim Jones";
    jimmy.hometown = @"Harlem, NY";
    
    // Jim Jones albums
    Album *jimmyAlbum = [NSEntityDescription insertNewObjectForEntityForName:@"Album" inManagedObjectContext:context];
    
    jimmyAlbum.albumId = [jimmyAlbum assignObjectId];
    
    jimmyAlbum.title = @"On My Way to Church";
    jimmyAlbum.released = [dateFormatter dateFromString:@"2004"];
    
    Album *jimmyAlbum2 = [NSEntityDescription insertNewObjectForEntityForName:@"Album" inManagedObjectContext:context];
    
    jimmyAlbum2.albumId = [jimmyAlbum2 assignObjectId];
    
    jimmyAlbum2.title = @"Harlem: Diary of a Summer";
    jimmyAlbum2.released = [dateFormatter dateFromString:@"2005"];
    
    Album *jimmyAlbum3 = [NSEntityDescription insertNewObjectForEntityForName:@"Album" inManagedObjectContext:context];
    
    jimmyAlbum3.albumId = [jimmyAlbum3 assignObjectId];
    
    jimmyAlbum3.title = @"Hustler's P.O.M.E. (Product of My Environment)";
    jimmyAlbum3.released = [dateFormatter dateFromString:@"2006"];
    
    
    // Freekey Zekey
    Artist *freekey = [NSEntityDescription insertNewObjectForEntityForName:@"Artist" inManagedObjectContext:context];
    
    freekey.artistId = [freekey assignObjectId];
    
    freekey.name = @"Freekey Zekey";
    freekey.hometown = @"Harlem, NY";
    
    Album *freekeyAlbum = [NSEntityDescription insertNewObjectForEntityForName:@"Album" inManagedObjectContext:context];
    
    freekeyAlbum.albumId = [freekeyAlbum assignObjectId];
    
    freekeyAlbum.title = @"Book of Ezekiel";
    freekeyAlbum.released = [dateFormatter dateFromString:@"2007"];
    
    
     // Set relationships
    [juelzAlbum setArtist:juelz];
    [juelzAlbum2 setArtist:juelz];
    [juelz addAlbums:[NSSet setWithObjects:juelzAlbum, juelzAlbum2, nil]];
    
    [jimmyAlbum setArtist:jimmy];
    [jimmyAlbum2 setArtist:jimmy];
    [jimmyAlbum3 setArtist:jimmy];
    [jimmy addAlbums:[NSSet setWithObjects:jimmyAlbum, jimmyAlbum2, jimmyAlbum3, nil]];
    
    [freekeyAlbum setArtist:freekey];
    [freekey addAlbumsObject:freekeyAlbum];
    
    // Set relationships
    [label addArtists:[NSSet setWithObjects:juelz, jimmy, freekey, nil]];
    
    
    // Save everything
    [context saveOnSuccess:^{
        NSLog(@"The save was successful!");
    } onFailure:^(NSError *error) {
        NSLog(@"The save wasn't successful: %@", [error localizedDescription]);
    }];
}

- (void) delete {
    // Grab the context
    NSManagedObjectContext *context = [self.coreDataStore contextForCurrentThread];
    
    //  We're looking to grab an artist
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Artist"
                                              inManagedObjectContext:context];
    
    [fetchRequest setEntity:entity];
    
    // We specify that we only want Freekey Zekey
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", @"Freekey Zekey"];
    [fetchRequest setPredicate:predicate];
    
    [context executeFetchRequest:fetchRequest onSuccess:^(NSArray *results) {
        // Grab the artist and delete
        Artist *freekey = [results objectAtIndex:0];
        [freekey.label removeArtistsObject:freekey];
        
        // Save everything
        [context saveOnSuccess:^{
            NSLog(@"The save was successful!");
        } onFailure:^(NSError *error) {
            NSLog(@"The save wasn't successful: %@", [error localizedDescription]);
        }];
    } onFailure:^(NSError *error) {
        NSLog(@"Error fetching: %@", error);
    }];
}

@end
