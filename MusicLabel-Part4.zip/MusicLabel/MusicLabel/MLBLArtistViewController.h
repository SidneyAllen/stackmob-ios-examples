//
//  MLBLArtistViewController.h
//  MusicLabel
//
//  Created by Carl Atupem on 12/11/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MLBLAppDelegate.h"
#import "Label.h"
#import "Artist.h"

@interface MLBLArtistViewController : UITableViewController

// An array to house all of our fetched Artist objects
@property (strong, nonatomic) NSArray *artistArray;

//The id of the parent object
@property (strong, nonatomic) NSManagedObjectID *labelID;

@end
