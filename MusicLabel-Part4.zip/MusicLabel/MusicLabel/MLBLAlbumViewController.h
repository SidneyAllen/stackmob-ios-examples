//
//  MLBLAlbumViewController.h
//  MusicLabel
//
//  Created by Carl Atupem on 12/11/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MLBLAppDelegate.h"
#import "Artist.h"
#import "Album.h"

@interface MLBLAlbumViewController : UITableViewController

// An array to house our Album objects
@property (strong, nonatomic) NSArray *albumArray;

@property (strong, nonatomic) NSManagedObjectID *artistID;

@end
