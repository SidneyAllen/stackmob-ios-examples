//
//  Label.m
//  MusicLabel
//
//  Created by Carl Atupem on 12/18/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "Label.h"
#import "Artist.h"


@implementation Label

@dynamic founded;
@dynamic genre;
@dynamic name;
@dynamic labelId;
@dynamic artists;

@end
