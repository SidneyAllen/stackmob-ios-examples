//
//  Album.m
//  MusicLabel
//
//  Created by Carl Atupem on 12/18/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "Album.h"
#import "Artist.h"


@implementation Album

@dynamic released;
@dynamic title;
@dynamic albumId;
@dynamic artist;

@end
