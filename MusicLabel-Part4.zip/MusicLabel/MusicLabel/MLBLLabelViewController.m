//
//  MLBLLabelViewController.m
//  MusicLabel
//
//  Created by Carl Atupem on 12/10/12.
//  Copyright (c) 2012 StackMob. All rights reserved.
//

#import "MLBLLabelViewController.h"
#import "MLBLLabelEntryViewController.h"
#import "MLBLArtistViewController.h"
#import "StackMob.h"

@interface MLBLLabelViewController ()

@end

@implementation MLBLLabelViewController

@synthesize labelArray;


- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addItem)];
    
    self.navigationItem.rightBarButtonItem = item;
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    
    // Here we call the method to load the table data
    [self loadTableData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    
    // We only need to return 1 for this table view
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    
    // We'll return the count of the objects in labelArray
    return [labelArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    // Grab the label
    Label *label = [self.labelArray objectAtIndex:indexPath.row];
    cell.textLabel.text = label.name;
    
    return cell;
}


-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    return UITableViewCellEditingStyleDelete;
    
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        
         NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
        
        // Grab the label
        Label *label = [self.labelArray objectAtIndex:indexPath.row];
        
        [context deleteObject:[context objectWithID:[label objectID]]];
        
        // Save everything
        [context saveOnSuccess:^{
            NSLog(@"The save was successful!");
        } onFailure:^(NSError *error) {
            NSLog(@"The save wasn't successful: %@", [error localizedDescription]);
        }];
        
        NSMutableArray *array = [self.labelArray mutableCopy];
        [array removeObjectAtIndex:indexPath.row];
        self.labelArray = array;
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
}



#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    MLBLArtistViewController *artistViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ArtistViewController"];
    
    // Grab the label
    Label *label = [self.labelArray objectAtIndex:indexPath.row];
    
    artistViewController.labelID = [label objectID];
    
    
    [self.navigationController pushViewController:artistViewController animated:YES];
}

#pragma mark - Private methods

- (MLBLAppDelegate *)appDelegate {
    return (MLBLAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void) loadTableData {
    
    NSManagedObjectContext *context = [[[self appDelegate] coreDataStore] contextForCurrentThread];
    
    // Construct a fetch request
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Label"
                                              inManagedObjectContext:context];
    
    [fetchRequest setEntity:entity];
    
    // Add an NSSortDescriptor to sort the labels alphabetically
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    [fetchRequest setSortDescriptors:sortDescriptors];
    
    
    NSError *error = nil;
    self.labelArray = [context executeFetchRequestAndWait:fetchRequest error:&error];
    [self.tableView reloadData];
}

- (void) addItem {
    
    MLBLLabelEntryViewController *labelEntryViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"LabelEntryViewController"];
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:labelEntryViewController];
    
    [self presentViewController:navigationController animated:YES completion:nil];
    
}

@end
