//
//  HUESignInViewController.m
//  Hue
//
//  Created by Carl Atupem on 1/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import "HUESignInViewController.h"
#import "HUEAppDelegate.h"
#import "HUETabBarController.h"
#import <FacebookSDK/FacebookSDK.h>

@interface HUESignInViewController ()

@end

@implementation HUESignInViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.client = [self.appDelegate client];
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Facebook methods

- (void)createUser {
    
    [self.client createUserWithFacebookToken:[NSString stringWithFormat:@"%@",FBSession.activeSession.accessToken] onSuccess:^(NSDictionary *result) {
        NSLog(@"Success creating user %@", result);
        
        [self loginUser];
    } onFailure:^(NSError *error) {
        NSLog(@"Error: %@", error);
        // User already exists with this FB Token, call Login method
        if (error.code == 401) {
            [self loginUser];
        }
    }];
}

- (void)loginUser {
    
    [self.client loginWithFacebookToken:FBSession.activeSession.accessToken onSuccess:^(NSDictionary *result) {
        NSLog(@"Logged In");
        // User is logged in
        
        HUETabBarController *tabBarController = [self.storyboard instantiateViewControllerWithIdentifier:@"TabBarController"];
        
        [self.navigationController pushViewController:tabBarController animated:YES];
        
        
    } onFailure:^(NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}


- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error
{
    switch (state) {
        case FBSessionStateOpen:
            [self createUser];
            break;
        case FBSessionStateClosed:
            [FBSession.activeSession closeAndClearTokenInformation];
            // User is logged out
            break;
        case FBSessionStateClosedLoginFailed:
            [FBSession.activeSession closeAndClearTokenInformation];
            break;
        default:
            break;
    }
    
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Error"
                                  message:error.localizedDescription
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
}


#pragma mark - Private methods

- (HUEAppDelegate *)appDelegate {
    return (HUEAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (IBAction)signInWithFacebook:(id)sender {
    
    [FBSession openActiveSessionWithReadPermissions:nil allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState status, NSError *error) {
        [self sessionStateChanged:session state:status error:error];
    }];
}

@end
