//
//  HUEProfileViewController.m
//  Hue
//
//  Created by Carl Atupem on 1/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import "HUEProfileViewController.h"
#import "HUEAppDelegate.h"

@interface HUEProfileViewController ()

@end

@implementation HUEProfileViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if (FBSession.activeSession.isOpen) {
        [[FBRequest requestForMe] startWithCompletionHandler:
         ^(FBRequestConnection *connection,
           NSDictionary<FBGraphUser> *user,
           NSError *error) {
             if (!error) {
                 self.profileLabel.text = user.name;
                 self.profilePictureView.profileID = user.id;
             }
         }];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private methods

- (HUEAppDelegate *)appDelegate {
    return (HUEAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (IBAction)dismiss:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)signOut:(id)sender {
    
    [[[self appDelegate] client] logoutOnSuccess:^(NSDictionary *result) {
        [FBSession.activeSession closeAndClearTokenInformation];
        [self dismissViewControllerAnimated:YES completion:nil];
    } onFailure:^(NSError *error) {
        
    }];
}

@end
