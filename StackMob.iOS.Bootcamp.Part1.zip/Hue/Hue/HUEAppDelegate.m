//
//  HUEAppDelegate.m
//  Hue
//
//  Created by Carl Atupem on 1/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import "HUEAppDelegate.h"
#import "HUESignInViewController.h"
#import "HUETabBarController.h"
#import <FacebookSDK/FacebookSDK.h>

@implementation HUEAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    self.client = [[SMClient alloc] initWithAPIVersion:@"0" publicKey:@"YOUR_PUBLIC_KEY"];
    
    // Grab the storyboard
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard"
                                                         bundle: nil];
    
    // Initialize the sign in view as the root controller
    HUESignInViewController *signInViewController = [storyboard instantiateViewControllerWithIdentifier:@"SignInViewController"];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:signInViewController];
    navigationController.navigationBarHidden = YES;
    
    if ([self.client isLoggedIn]) {
        // If the user is signed in, go directly to the main view
        [FBSession openActiveSessionWithReadPermissions:nil allowLoginUI:NO completionHandler:^(FBSession *session, FBSessionState status, NSError *error) {
            
        }];
        
        
        HUETabBarController *tabBarController = [storyboard instantiateViewControllerWithIdentifier:@"TabBarController"];
        tabBarController.navigationItem.hidesBackButton = YES;
        [navigationController pushViewController:tabBarController animated:NO];
        self.viewController = navigationController;
        [self.window setRootViewController:self.viewController];
        
    }
    else {
        NSLog(@"Logged Out");
        // Otherwise, go to the sign in view
        self.viewController = navigationController;
        [self.window setRootViewController:self.viewController];
    }
    
    return YES;
}

- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    // attempt to extract a token from the url
    return [FBSession.activeSession handleOpenURL:url];
}

							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    [FBSession.activeSession handleDidBecomeActive];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    
     [FBSession.activeSession close];
}

@end
