//
//  main.m
//  Hue
//
//  Created by Carl Atupem on 1/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HUEAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HUEAppDelegate class]));
    }
}
