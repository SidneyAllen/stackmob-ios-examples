//
//  HUEProfileViewController.h
//  Hue
//
//  Created by Carl Atupem on 1/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
#import "StackMob.h"

@interface HUEProfileViewController : UIViewController
- (IBAction)dismiss:(id)sender;
- (IBAction)signOut:(id)sender;


@property (strong, nonatomic) IBOutlet FBProfilePictureView *profilePictureView;
@property (strong, nonatomic) IBOutlet UILabel *profileLabel;
@property (strong, nonatomic) SMClient *client;

@end