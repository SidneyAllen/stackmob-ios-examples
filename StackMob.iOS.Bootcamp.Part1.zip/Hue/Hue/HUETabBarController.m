//
//  HUETabBarController.m
//  Hue
//
//  Created by Carl Atupem on 1/7/13.
//  Copyright (c) 2013 StackMob. All rights reserved.
//

#import "HUETabBarController.h"
#import "HUEAppDelegate.h"
#import <QuartzCore/QuartzCore.h>
#import "HUEProfileViewController.h"

@interface HUETabBarController ()

@end

@implementation HUETabBarController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated {
    if (![[[self appDelegate] client] isLoggedIn]) {
        [self.navigationController popToRootViewControllerAnimated:NO];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.navigationController setNavigationBarHidden:NO];
    
    UIBarButtonItem *profile = [[UIBarButtonItem alloc] initWithTitle:@"Profile" style:UIBarButtonItemStyleBordered target:self action:@selector(showProfile:)];
    
    self.navigationItem.leftBarButtonItem = profile;
    
    // Draw a shadow offset on the tabBar
    UITabBar *tabBar = self.tabBar;
    tabBar.layer.shadowColor = [[UIColor blackColor] CGColor];
    tabBar.layer.shadowOffset = CGSizeMake(0.0, -10);
    tabBar.layer.shadowOpacity = 0.20;
    tabBar.layer.masksToBounds = NO;
    tabBar.layer.shouldRasterize = YES;
    
    // Disable the tabBarItem hidden by the Camera button
    UITabBarItem *item1 = [tabBar.items objectAtIndex:1];
    [item1 setEnabled:FALSE];
    
    // Add Camera button
    UIButton *cameraButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [cameraButton setFrame:CGRectMake(110, 3.0, 100, 44)];
    [cameraButton addTarget:self action:@selector(showCamera:) forControlEvents:UIControlEventTouchUpInside];
    [self.tabBar addSubview:cameraButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (HUEAppDelegate *)appDelegate {
    return (HUEAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (IBAction)showCamera:(id)sender {
    NSLog(@"camera");
    
    
}

- (IBAction)showProfile:(id)sender {
    
    HUEProfileViewController *profileViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    [self presentViewController:profileViewController animated:YES completion:nil];
}

@end
